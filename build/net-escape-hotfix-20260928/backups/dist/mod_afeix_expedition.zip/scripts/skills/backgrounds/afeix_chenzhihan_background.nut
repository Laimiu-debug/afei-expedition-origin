// Generated; retain native attributes, event eligibility and save layout.
this.afeix_chenzhihan_background <- this.inherit("scripts/skills/backgrounds/daytaler_background", {
    m = {},
    function create() {
        this.daytaler_background.create();
        this.m.ID = "background.afeix_chenzhihan";
        ::AfeixExpedition.configureCharacterBackground(this, "chenzhihan");
    },
    function buildDescription(final = false) {
        ::AfeixExpedition.configureCharacterBackground(this, "chenzhihan");
    },
    function onBuildDescription() { return this.m.RawDescription; }
});
