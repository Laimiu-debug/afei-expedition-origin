this.afeix_laoma_grip <- this.inherit("scripts/items/weapons/two_handed_hammer", {
    m = {},
    function create() {
        this.two_handed_hammer.create();
        this.m.ID = "weapon.afeix_laoma_grip";
        this.m.Name = "老马的垂直握把";
        this.m.Description = "老马拍着胸脯保证，这握把主打一个‘稳’。铁匠试敲了一下，盔甲没稳住。商品不附说明书，使用方法就六个字：双手握紧，敲他。\n\n单体重击命中后，对命中部位额外削减最多 40 点护甲；不溢出为生命伤害，横扫和反击不触发。";
        this.m.Categories = "双手锤";
        this.m.ItemType = this.m.ItemType | this.Const.Items.ItemType.Named;
        this.m.IconLarge = "weapons/afeix_laoma_grip.png";
        this.m.Icon = "weapons/afeix_laoma_grip_70x70.png";
        this.m.ArmamentIcon = "icon_afeix_laoma_grip";
        this.m.Value = 12000;
        this.m.Condition = 100.0; this.m.ConditionMax = 100.0;
        this.m.RegularDamage = 80; this.m.RegularDamageMax = 100;
        this.m.ArmorDamageMult = 2.25; this.m.DirectDamageMult = 0.5;
        this.m.StaminaModifier = -18;
    },
    function onEquip() {
        this.two_handed_hammer.onEquip();
        local s = this.getContainer().getActor().getSkills().getSkillByID("actives.smite");
        if (s != null) s.setFatigueCost(20);
        this.addSkill(this.new("scripts/skills/special/afeix_grip_breaker"));
    }
});
