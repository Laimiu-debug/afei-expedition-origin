// Presentation-only company banner. Keep the saved numeric banner variant for
// native consumers; the original battle standard keeps its stats and skills.
::AfeixExpedition.ToadBanners <- [
    {key="classic", name="黑金蛤蟆", suffix=""},
    {key="front", name="正面踩球蛤蟆", suffix="_front"},
    {key="profile", name="侧身踩球蛤蟆", suffix="_profile"},
    {key="medallion", name="圆章蛤蟆", suffix="_medallion"},
    {key="golden", name="黄金天使蛙", suffix="_golden"}
];
::AfeixExpedition.toadBanner <- function() {
    local key = "classic";
    if ("World" in getroottable() && ::World != null && "Flags" in ::World && ::World.Flags != null)
        key = this.get("banner_style", "classic");
    foreach (banner in this.ToadBanners) if (banner.key == key) return banner;
    return this.ToadBanners[0];
};
::AfeixExpedition.chooseToadBanner <- function(key) {
    if (!this.isOrigin() || ::Tactical.isActive() || ::World.State == null
        || ::World.State.getCombatStartTime() != 0 || ::World.State.getPlayer() == null)
        return this.result(false, "请回到大地图后更换旗帜。");
    foreach (banner in this.ToadBanners) {
        if (banner.key != key) continue;
        this.set("banner_style", key);
        this.syncToadBanner();
        return this.result(true, "已换上“" + banner.name + "”旗帜。");
    }
    return this.result(false, "没有找到这款旗帜。");
};
::AfeixExpedition.toadBannerOption <- function(banner) {
    local label = (this.toadBanner().key == banner.key ? "[当前] " : "换上：") + banner.name;
    return this.ledgerAction(label, function() { return ::AfeixExpedition.chooseToadBanner(banner.key); }, "banners");
};
::AfeixExpedition.bannerLedgerPage <- function(event, page) {
    if (page != "company" && page != "banners") return null;
    local screen = {ID=page, Text="", Image="", List=[], Characters=[], Options=[], function start(event) {}};
    if (page == "company") {
        screen.Text = "战团事务\n\n安排伙伴研习技能，或为战团换一面旗帜。";
        if ("trainingLedgerPage" in this) screen.Options.push(this.ledgerNav("研习专属技能", "training"));
        screen.Options.push(this.ledgerNav("更换旗帜", "banners"));
        screen.Options.push(this.ledgerNav("返回名册", "home"));
    } else {
        local banner = this.toadBanner();
        screen.Text = "[img]gfx/ui/banners/banner_afeix_toad" + banner.suffix + "s.png[/img]更换旗帜\n\n当前：" + banner.name
            + "。\n\n点选即可换旗，选择会随存档保留。大地图旗与已获得的战旗使用相同图案。";
        foreach (choice in this.ToadBanners) screen.Options.push(this.toadBannerOption(choice));
        screen.Options.push(this.ledgerNav("返回战团事务", "company"));
    }
    return screen;
};
::AfeixExpedition.applyToadStandardArt <- function(actor) {
    if (actor == null) return;
    if (actor.hasSprite("background")) actor.getSprite("background").setBrush("afeix_toad_standard" + this.toadBanner().suffix);
    if (actor.hasSprite("shaft")) actor.getSprite("shaft").setBrush("player_banner_15_shaft");
    actor.setDirty(true);
};
::mods_hookNewObject("states/world/asset_manager", function(o) {
    local getBanner = o.getBanner;
    o.getBanner = function() {
        return ::AfeixExpedition.isOrigin() ? "banner_afeix_toad" + ::AfeixExpedition.toadBanner().suffix : getBanner.bindenv(this)();
    };
});
::AfeixExpedition.syncToadBanner <- function() {
    if (!this.isOrigin() || ::World.State == null) return;
    local party = ::World.State.getPlayer();
    local brush = "banner_afeix_toad" + this.toadBanner().suffix;
    if (party == null || !::doesBrushExist(brush)) return;
    foreach (name in ["banner", "zoom_banner"])
        if (party.hasSprite(name)) party.getSprite(name).setBrush(brush);
    // Items can deserialize before Assets restores the campaign origin.
    // Refresh their presentation after world load without re-equipping skills.
    foreach (bro in this.roster()) {
        foreach (item in bro.getItems().getAllItems())
            if (item != null && item.getID() == "weapon.player_banner") item.updateVariant();
        local held = bro.getItems().getItemAtSlot(::Const.ItemSlot.Mainhand);
        if (held != null && held.getID() == "weapon.player_banner") this.applyToadStandardArt(bro);
    }
    foreach (item in ::World.Assets.getStash().getItems())
        if (item != null && item.getID() == "weapon.player_banner") item.updateVariant();
};
::mods_hookExactClass("states/world_state", function(o) {
    local onDeserialize = o.onDeserialize;
    o.onDeserialize = function(input) {
        local result = onDeserialize.bindenv(this)(input);
        ::AfeixExpedition.syncToadBanner();
        return result;
    };
});
::mods_hookExactClass("items/tools/player_banner", function(o) {
    local updateVariant = o.updateVariant, onEquip = o.onEquip;
    o.updateVariant = function() {
        local result = updateVariant.bindenv(this)();
        if (::AfeixExpedition.isOrigin()) {
            local suffix = ::AfeixExpedition.toadBanner().suffix;
            this.m.Icon = "weapons/afeix_toad_banner" + suffix + "_70x70.png";
            this.m.IconLarge = "weapons/afeix_toad_banner" + suffix + ".png";
        }
        return result;
    };
    o.onEquip = function() {
        local result = onEquip.bindenv(this)();
        if (::AfeixExpedition.isOrigin()) {
            this.updateVariant();
            local actor = this.getContainer().getActor();
            ::AfeixExpedition.applyToadStandardArt(actor);
        }
        return result;
    };
});
