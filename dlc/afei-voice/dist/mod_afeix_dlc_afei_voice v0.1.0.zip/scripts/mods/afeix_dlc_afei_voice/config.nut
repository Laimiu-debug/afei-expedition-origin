// Original voice excerpts from the supplied video; see audio/source.json.
// Candidate cuts await listening review and in-game acceptance.
::AfeixVoiceDLC.HurtSounds <- [
    "sounds/afeix_dlc_afei_voice/afei_hurt_01.wav",
    "sounds/afeix_dlc_afei_voice/afei_hurt_02.wav",
    "sounds/afeix_dlc_afei_voice/afei_hurt_03.wav",
    "sounds/afeix_dlc_afei_voice/afei_hurt_04.wav",
    "sounds/afeix_dlc_afei_voice/afei_hurt_05.wav"
];
::AfeixVoiceDLC.VolumeMult <- 0.85;
