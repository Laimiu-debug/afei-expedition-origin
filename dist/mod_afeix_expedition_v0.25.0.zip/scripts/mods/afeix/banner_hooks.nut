// Presentation-only company banner. Keep the saved numeric banner variant for
// native consumers; the original battle standard keeps its stats and skills.
::AfeixExpedition.applyToadStandardArt <- function(actor) {
    if (actor == null) return;
    if (actor.hasSprite("background")) actor.getSprite("background").setBrush("afeix_toad_standard");
    if (actor.hasSprite("shaft")) actor.getSprite("shaft").setBrush("player_banner_15_shaft");
};
::mods_hookNewObject("states/world/asset_manager", function(o) {
    local getBanner = o.getBanner;
    o.getBanner = function() {
        return ::AfeixExpedition.isOrigin() ? "banner_afeix_toad" : getBanner.bindenv(this)();
    };
});
::AfeixExpedition.syncToadBanner <- function() {
    if (!this.isOrigin() || ::World.State == null) return;
    local party = ::World.State.getPlayer();
    if (party == null || !::doesBrushExist("banner_afeix_toad")) return;
    foreach (name in ["banner", "zoom_banner"])
        if (party.hasSprite(name)) party.getSprite(name).setBrush("banner_afeix_toad");
    // Items can deserialize before Assets restores the campaign origin.
    // Refresh their presentation after world load without re-equipping skills.
    foreach (bro in this.roster()) {
        foreach (item in bro.getItems().getAllItems())
            if (item != null && item.getID() == "weapon.player_banner") item.updateVariant();
        local held = bro.getItems().getItemAtSlot(::Const.ItemSlot.Mainhand);
        if (held != null && held.getID() == "weapon.player_banner") this.applyToadStandardArt(bro);
    }
    foreach (item in ::World.Assets.getStash().getItems())
        if (item != null && item.getID() == "weapon.player_banner") item.updateVariant();
};
::mods_hookExactClass("states/world_state", function(o) {
    local onDeserialize = o.onDeserialize;
    o.onDeserialize = function(input) {
        local result = onDeserialize.bindenv(this)(input);
        ::AfeixExpedition.syncToadBanner();
        return result;
    };
});
::mods_hookExactClass("items/tools/player_banner", function(o) {
    local updateVariant = o.updateVariant, onEquip = o.onEquip;
    o.updateVariant = function() {
        local result = updateVariant.bindenv(this)();
        if (::AfeixExpedition.isOrigin()) {
            this.m.Icon = "weapons/afeix_toad_banner_70x70.png";
            this.m.IconLarge = "weapons/afeix_toad_banner.png";
        }
        return result;
    };
    o.onEquip = function() {
        local result = onEquip.bindenv(this)();
        if (::AfeixExpedition.isOrigin()) {
            this.updateVariant();
            local actor = this.getContainer().getActor();
            ::AfeixExpedition.applyToadStandardArt(actor);
        }
        return result;
    };
});
