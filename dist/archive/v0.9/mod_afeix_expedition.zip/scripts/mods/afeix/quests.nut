local A = ::AfeixExpedition;
// Historical source groups retained only for old development catalogs; never unlock gameplay.
A.Chapters <- [
    { id = 1, name = "刀一黑队", required = 1 },
    { id = 2, name = "刀二蓝队", required = 3 },
    { id = 3, name = "九月联动", required = 6 },
    { id = 4, name = "0.5 飞团", required = 9 },
    { id = 5, name = "旅途来客", required = 12 }
];
A.completedDeliveries <- function() {
    // v0.1 stored only the single finished delivery, not a total. Credit it once.
    return this.get("deliveries_completed", this.get("delivery_state") == 2 ? 1 : 0);
};
A.migrateProgress <- function() {
    if (!this.isOrigin()) return;
    this.set("deliveries_completed", this.completedDeliveries());
    // Retire old unpaid ledger letters without a penalty. Completed work survives.
    if (!this.get("native_letters_migrated", false)) {
        if (this.get("delivery_state") == 1) {
            this.set("delivery_state", 3);
            this.set("legacy_letter_retired", true);
        }
        this.set("native_letters_migrated", true);
    }
    this.set("schema", this.Schema);
};
A.progressCount <- function() { return this.completedDeliveries() + this.get("paid_contracts"); };
A.isRecruitUnlocked <- function(key) {
    return key in this.Characters && !this.Characters[key].isCaptain
        && this.isCharacterKnown(key) && this.get("encounter_done_" + key, false);
};
A.DeliveryMaxRoadTiles <- 30;
A.findDeliveryRoute <- function(home) {
    local best = null, shortest = 999999;
    local settings = ::World.getNavigator().createSettings();
    settings.ActionPointCosts = ::Const.World.TerrainTypeNavCost;
    settings.RoadMult = 0.2;
    settings.RoadOnly = true;
    foreach (town in ::World.EntityManager.getSettlements()) {
        if (!town.isAlive() || town.getID() == home.getID() || town.isMilitary() || !town.isAlliedWithPlayer()) continue;
        if (!home.isConnectedToByRoads(town)) continue;
        local path = ::World.getNavigator().findPath(home.getTile(), town.getTile(), settings, 0);
        if (path.isEmpty()) continue;
        local distance = path.getSize();
        // Real road length only: never fall back to a straight line across water.
        if (distance <= 0 || distance > this.DeliveryMaxRoadTiles) continue;
        if (distance < shortest) { best = town; shortest = distance; }
    }
    return best == null ? null : { town = best, tiles = shortest };
};
A.findDeliveryTown <- function(home) {
    local route = this.findDeliveryRoute(home);
    return route == null ? null : route.town;
};
A.ensureTownLetter <- function(town) {
    if (!this.isOrigin() || town == null || !town.isAlive() || town.isMilitary() || !town.isAlliedWithPlayer()) return;
    this.migrateProgress();
    // Respect the native one-contract-at-a-time rule and never replace a job.
    if (::World.Contracts.getActiveContract() != null) return;
    foreach (c in ::World.Contracts.getOpenContracts())
        if (c.getType() == "contract.afeix_letter" && c.getHome() != null
            && c.getHome().getID() == town.getID() && c.isValid() && !c.isTimedOut()) return;
    local faction = town.getFactionOfType(::Const.FactionType.Settlement);
    if (faction == null) faction = town.getFactionOfType(::Const.FactionType.OrientalCityState);
    if (faction == null) return;
    local employer = faction.getRandomCharacter();
    if (employer == null) return;
    local route = this.findDeliveryRoute(town);
    if (route == null) return;
    local c = ::new("scripts/contracts/contracts/afeix_letter_contract");
    c.setFaction(faction.getID());
    c.setEmployerID(employer.getID());
    c.setHome(town);
    c.setOrigin(town);
    c.setup(route.town, route.tiles);
    ::World.Contracts.addContract(c);
};
// The contract adapter supplies a successful terminal state and observed money received.
// Contract IDs are native persistent IDs; an old completion cannot unlock or count twice.
A.recordContract <- function(id, cancelled, payment) {
    if (!this.isOrigin() || cancelled || payment <= 0 || this.get("contract_done_" + id, false)) return false;
    this.set("contract_done_" + id, true);
    this.set("paid_contracts", this.get("paid_contracts") + 1);
    return true;
};
A.questSummary <- function() {
    local text = "委托在城镇契约栏领取。接下后，世界地图的任务栏会显示目标；短途送信抵达收信城镇后即可交付，不必打开名册。";
    if ("Contracts" in ::World && ::World.Contracts != null) {
        local active = ::World.Contracts.getActiveContract();
        if (active != null) text += "\n\n正在办理：" + active.getName() + "。";
    }
    if (this.get("legacy_letter_retired", false)) text += "\n\n旧版尚未交付的送信委托已免罚撤销，请在城镇重新接取短途委托。已完成的记录保留。";
    return text + "\n\n已完成委托：" + this.progressCount() + " 份。";
};
