// Keep native gameplay; only the injury-layer renderer is replaced for portraits.
local hookPortraitActor = function(o) {
    local setDirty = o.setDirty;
    o.setDirty = function(value) {
        ::AfeixExpedition.hideOriginalPortraitParts(this);
        return setDirty(value);
    };
    local onAppearanceChanged = o.onAppearanceChanged;
    o.onAppearanceChanged = function(appearance, setDirty = true) {
        local result = onAppearanceChanged(appearance, setDirty);
        ::AfeixExpedition.syncCharacterArt(this); return result;
    };
    local onUpdateInjuryLayer = o.onUpdateInjuryLayer;
    o.onUpdateInjuryLayer = function() {
        local A = ::AfeixExpedition;
        if ("afeixDeathVisual" in this.m && this.m.afeixDeathVisual) return;
        if (!A.isCharacterArtSuspended(this) && A.isArtCharacter(this) && A.hasPortraitArt(this)) {
            A.syncCharacterArt(this); return;
        }
        if (!A.isCharacterArtSuspended(this) && "afeixPortraitActive" in this.m && this.m.afeixPortraitActive)
            A.restoreNativeCharacterBody(this);
        return onUpdateInjuryLayer();
    };
    local onFactionChanged = o.onFactionChanged;
    o.onFactionChanged = function() {
        local result = onFactionChanged(); ::AfeixExpedition.syncCharacterArt(this); return result;
    };
    local onDeath = o.onDeath;
    o.onDeath = function(killer, skill, tile, fatalityType) {
        local A = ::AfeixExpedition, brush = A.characterPortraitBrush(this);
        if (brush == null || !A.hasPortraitArt(this, brush)) {
            if (brush != null && "afeixPortraitActive" in this.m && this.m.afeixPortraitActive) A.suspendCharacterArt(this);
            return onDeath(killer, skill, tile, fatalityType);
        }
        local depth = "afeixArtSuspendDepth" in this.m ? this.m.afeixArtSuspendDepth : 0;
        this.m.afeixArtSuspendDepth <- depth + 1;
        local saved = A.beginPortraitDeath(this), result = null;
        try { result = onDeath(killer, skill, tile, fatalityType); }
        catch (error) {
            A.endPortraitDeath(this, saved); this.m.afeixArtSuspendDepth = depth; throw error;
        }
        A.endPortraitDeath(this, saved); this.m.afeixArtSuspendDepth = depth;
        A.replacePortraitCorpse(this, tile, brush); return result;
    };
};
::mods_hookExactClass("entity/tactical/player", function(o) {
    hookPortraitActor(o);
    local onInit = o.onInit;
    o.onInit = function() {
        this.m.afeixArtSuspendDepth <- 0;
        local result = onInit();
        // Ordinary players and other origins receive no extra sprite.
        ::AfeixExpedition.syncCharacterArt(this); return result;
    };
    local onDeserialize = o.onDeserialize;
    o.onDeserialize = function(input) {
        this.m.afeixArtSuspendDepth <- 0; this.m.afeixNativeArt <- null; this.m.afeixPortraitActive <- false;
        local result = onDeserialize(input);
        ::AfeixExpedition.syncCharacterArt(this); return result;
    };
    local onCombatFinished = o.onCombatFinished;
    o.onCombatFinished = function() {
        local result = onCombatFinished(); ::AfeixExpedition.syncCharacterArt(this); return result;
    };
    local onSerialize = o.onSerialize;
    o.onSerialize = function(output) {
        local A = ::AfeixExpedition;
        if (!A.isArtCharacter(this)) return onSerialize(output);
        local depth = "afeixArtSuspendDepth" in this.m ? this.m.afeixArtSuspendDepth : 0;
        this.m.afeixArtSuspendDepth <- depth + 1;
        local result = null;
        try { A.suspendCharacterArt(this); result = onSerialize(output); }
        catch (error) {
            this.m.afeixArtSuspendDepth = depth;
            if (depth == 0) A.syncCharacterArt(this);
            throw error;
        }
        this.m.afeixArtSuspendDepth = depth;
        if (depth == 0) A.syncCharacterArt(this);
        return result;
    };
});
::mods_hookExactClass("entity/tactical/enemies/zombie_player", function(o) {
    hookPortraitActor(o);
    local onResurrected = o.onResurrected;
    o.onResurrected = function(info) {
        local A = ::AfeixExpedition;
        if (A.isOrigin() && info.Custom != null && "Body" in info.Custom && A.isPortraitBrush(info.Custom.Body))
            this.m.afeixResurrectedPortrait <- info.Custom.Body;
        local result = onResurrected(info); A.syncCharacterArt(this); return result;
    };
});
