::mods_hookExactClass("states/world_state", function(o) {
    local onKeyInput = o.onKeyInput;
    o.onKeyInput = function(key) {
        // Native key codes: F8 = 78, released = 0.
        if (key.getState() == 0 && key.getKey() == 78 && ::AfeixExpedition.openLedger()) return true;
        return onKeyInput(key);
    };
    local onDeserialize = o.onDeserialize;
    o.onDeserialize = function(input) {
        local result = onDeserialize(input);
        local A = ::AfeixExpedition;
        // Player deserialization can precede Assets restoring the saved origin.
        // The completed world load is the first reliable point for this check.
        A.PaymentContext = null;
        if (A.isOrigin()) {
            if ("migrateProgress" in A) A.migrateProgress();
            foreach (bro in A.roster()) A.restoreCharacterMetadata(bro);
            ::World.Assets.updateFormation();
        }
        return result;
    };
});

// These managers are native tables created with new(), not inherit() classes.
::mods_hookNewObject("states/world/asset_manager", function(o) {
    local updateFormation = o.updateFormation;
    o.updateFormation = function(considerMaxBros = false) {
        if (!::AfeixExpedition.isOrigin()) return updateFormation(considerMaxBros);
        this.m.BrothersMax = ::AfeixExpedition.RosterMax;
        this.m.BrothersMaxInCombat = ::AfeixExpedition.CombatMax;
        ::AfeixExpedition.enforceFormation();
    };
    local getFormation = o.getFormation;
    o.getFormation = function() {
        return ::AfeixExpedition.isOrigin() ? ::AfeixExpedition.formation() : getFormation();
    };
});

::mods_hookBaseClass("contracts/contract", function(o) {
    local onCombatVictory = o.onCombatVictory;
    o.onCombatVictory = function(combatID) {
        local A = ::AfeixExpedition;
        if ("noteCircleVictory" in A) A.noteCircleVictory(this.getID());
        return onCombatVictory(combatID);
    };
    // Native 1.5.2.3 invokes screen choices/start and state callbacks through
    // these methods. Wrapping the dispatcher retains native argument defaults.
    foreach (method in ["processInput", "setScreen", "setState", "update",
        "onActorKilled", "onActorRetreated", "onRetreatedFromCombat",
        "onCombatVictory", "onPartyDestroyed", "onLocationDestroyed"])
        o[method] = ::AfeixExpedition.wrapContractCallback(o[method]);
});

::mods_hookBaseClass("events/event", function(o) {
    foreach (method in ["fire", "processInput", "setScreen", "update"])
        o[method] = ::AfeixExpedition.wrapNonContractCallback(o[method]);
});

::mods_hookNewObject("states/world/asset_manager", function(o) {
    local addMoney = o.addMoney;
    o.addMoney = function(amount) {
        local A = ::AfeixExpedition;
        if (!A.isOrigin() || A.PaymentContext == null || amount <= 0) return addMoney(amount);
        local id = A.PaymentContext, before = this.getMoney();
        local result = addMoney(amount);
        local received = this.getMoney() - before;
        if (received > 0) A.noteContractIncome(id, received);
        return result;
    };
});

::mods_hookNewObject("contracts/contract_manager", function(o) {
    local finishActiveContract = o.finishActiveContract;
    o.finishActiveContract = function(cancelled = false) {
        local A = ::AfeixExpedition;
        if (!A.isOrigin() || this.m.Active == null) return finishActiveContract(cancelled);
        local id = this.m.Active.getID();
        local result = A.withPaymentContext(id, finishActiveContract, [this, cancelled]);
        // Commit only after the native manager actually closes the contract.
        if (this.m.Active == null) A.finishContractPayment(id, cancelled);
        return result;
    };
});

::mods_hookExactClass("entity/tactical/player", function(o) {
    local onDeath = o.onDeath;
    o.onDeath = function(killer, skill, tile, fatality) {
        local A = ::AfeixExpedition, key = A.characterId(this);
        if (A.isOrigin() && key != "" && fatality != ::Const.FatalityType.Unconscious)
            A.set("dead_" + key, true);
        return onDeath(killer, skill, tile, fatality);
    };
});

::mods_hookNewObject("ui/screens/character/character_screen", function(o) {
    local onDismissCharacter = o.onDismissCharacter;
    o.onDismissCharacter = function(data) {
        local A = ::AfeixExpedition, key = "";
        if (A.isOrigin()) key = A.characterId(::Tactical.getEntityByID(data[0]));
        local result = onDismissCharacter(data);
        if (key != "" && A.findCharacter(key) == null) A.set("departed_" + key, true);
        return result;
    };
});
