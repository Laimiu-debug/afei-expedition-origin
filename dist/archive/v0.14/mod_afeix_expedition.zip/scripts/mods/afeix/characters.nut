// Fictional recruitment scenes for the mod; these are not real-life biographies.
// Prototype level-1 balance only. Chapter 5 is a content group, not a confirmed team affiliation.
// Ordinary backgrounds, talents and equipment do not impose a class, species or exclusive skill.
// Stable keys preserve saves when the production roster order changes.
local A = ::AfeixExpedition;
A.CharacterOrder <- ["afei", "damou", "mocha", "bottle", "shuaizi", "lili", "xiaoyueya", "yuchujiu", "xiaoyubeike", "wangduidui", "laocai", "tiantong", "xiaoning", "xiaopangxu", "dae", "manyuemei", "xiaohani", "keke", "yuxiang", "tongzhu", "meiya", "wanshe", "tutu", "songnuanyang", "xiaogui", "naigai", "xiaojie", "bula", "suwa", "qianhan", "wangdazhi", "yaoyaoya", "yangmiemie", "chenzhihan"];
A.Characters <- {
    afei = {
        name = "阿飞", title = "队长", isCaptain = true, hireCost = 0, wage = 8,
        background = "daytaler_background", role = "前期薄弱，保留后续成长空间",
        description = "阿飞是远征团的三位开局队长之一。黑旗上的嘉豪二字很气派，旗底这位团长的本事却还没跟上，盾一沉就容易哇哇叫。他喜欢别人把目光投过来，衣领歪了也要先整一下；碰到真要拿队友冒险的决定，笑意却收得比谁都快。大谋能替他顶住前排，抹茶能替他算清账，可“这些人为什么跟你走”终究得由他回答。他想成为大哥，也想亲眼看见自己带来的人越走越稳。眼下，他还在起点。",
        attrs = [48, 92, 30, 95, 43, 32, 1, 0],
        stars = { MeleeSkill = 2, Bravery = 2, Stamina = 1 },
        equipment = ["weapons/bludgeon", "armor/thick_tunic", "helmets/headscarf", "shields/buckler_shield"],
        bag = [],
        chapter = 1,
        encounterTitle = null,
        encounterText = null,
        encounterChoices = null
    },
    damou = {
        name = "王大谋", title = "队长", isCaptain = true, hireCost = 0, wage = 15,
        background = "militia_background", role = "开局强势的前排盾卫，近防与决心成长",
        description = "王大谋是三位开局队长里先能把前排撑住的人。他认识的大哥很多，看见好枪法还会再认识一个，问完招式就顺势问人家愿不愿意换面旗。偷大哥是营里的玩笑，他倒并不觉得多请一位高手有什么丢人。真正站到队伍前面时，最先举起的仍是他自己的盾。阿飞尚且底气不足，他会当面嫌弃，也会留下来陪着练；抹茶追问新增的工钱，他会讨价还价，却不会装作没听见。",
        attrs = [62, 106, 49, 105, 66, 37, 10, 5],
        stars = { MeleeDefense = 3, Bravery = 2, Stamina = 1 },
        equipment = ["weapons/boar_spear", "armor/padded_leather", "helmets/aketon_cap", "shields/wooden_shield"],
        bag = [],
        chapter = 1,
        encounterTitle = null,
        encounterText = null,
        encounterChoices = null
    },
    mocha = {
        name = "午夜抹抹茶", title = "队长", isCaptain = true, hireCost = 0, wage = 10,
        background = "poacher_background", role = "普通水平的后排帮手",
        description = "午夜抹抹茶是黑旗的三位开局队长之一。别人还在讲将来，他已经把今天的饭钱拨到算盘另一边。营里那把地精算盘拨到最后，总能再找出一笔不该漏掉的钱：雇主加一句顺手，账上就添一行费用，阿飞加一句豪言，他便问准备从哪里付账。他拆台时不留情，替队友追账时也一样。弓可以放在后排，账本却总摆在三位队长中间；不少决定，是等那阵珠响停了才真正作数。",
        attrs = [55, 100, 43, 102, 52, 53, 4, 3],
        stars = { RangedSkill = 1, Bravery = 1 },
        equipment = ["weapons/hunting_bow", "armor/thick_tunic", "helmets/headscarf", "ammo/quiver_of_arrows"],
        bag = ["weapons/knife"],
        chapter = 1,
        encounterTitle = null,
        encounterText = null,
        encounterChoices = null
    },
    bottle = {
        name = "小酒瓶", title = "蛤妈", isCaptain = false, hireCost = 220, wage = 10,
        background = "daytaler_background", role = "九星核心：近攻、近防与决心；帮助阿飞成长",
        description = "小酒瓶是队员，阿飞喊人往前冲时，她往往已经看见了那个能挤过去的缺口。瓶队喜欢决赛，也喜欢有人肯把球交过来，却不乐意只当一句“你最强”后面的那个名字。蛤妈这外号落到她身上，是因为这个嗓门很大的团长确实还需要有人推一把。她能催他接球，也能看出他什么时候是在硬撑；自己想赢的事，同样不会因此让给他。提到那辆旧自行车，她先看的通常是链条，不是阿飞又讲了什么道理。",
        attrs = [56, 100, 44, 101, 57, 38, 5, 3],
        stars = { MeleeSkill = 3, MeleeDefense = 3, Bravery = 3 },
        equipment = ["weapons/shortsword", "armor/ragged_dark_surcoat", "helmets/hood", "shields/wooden_shield"],
        bag = [],
        chapter = 1,
        encounterTitle = "这回先接住",
        encounterText = "小酒瓶把旧球停在鞋尖前。阿飞刚夸完一句瓶队突破，球便轻轻滚向他脚下，他下意识让了半步。她看看球，又看看这个自称会带人的团长，笑问以后也准备这样给队友让路吗。旁边靠着待修的旧车，她手里还攥着一截沾油的布，修理铺留下的报价压在车铃下面，等他把话接下去。",
        encounterChoices = [
            { label = "把球停住，认真接下她的反问", outcome = "阿飞这回没躲开，把球轻轻拨回去。小酒瓶肯把自己的条件说给他听，邀请按原价保留；接球这件事，先记作两人之间的一个开头。", cost = 0, hireDiscount = 0 },
            { label = "付清她眼前的修车费用，再谈邀请", outcome = "修理费用按所选报价付清。小酒瓶敲了敲车铃，愿意给这位肯搭把手的团长一个更低的招募报价；优惠随邀请保留，是否正式入队仍要另谈。", cost = 50, hireDiscount = 80 }
        ]
    },
    shuaizi = {
        name = "白小帅子", title = "远征团队员", isCaptain = false, hireCost = 200, wage = 9,
        background = "militia_background", role = "可培养的持盾前排",
        description = "白小帅子不太会装胆大。热闹一起来，她会先确认门闩、盾带和旁边有没有同伴，嘴里的慢一点有时还带着急气。但要真从这道门过去，最后仍得听她数拍。四声鼓比十句保证有用，她连阿飞也不肯随便放行。小酒瓶往前找缺口，她更在意那条回来的路还在不在；这并不妨碍她嫌瓶队跑得太快。请她守住一个位置之前，最好把信号讲清楚，她会记得比发令的人还牢。",
        attrs = [58, 101, 45, 100, 55, 35, 7, 4],
        stars = { MeleeDefense = 2, Bravery = 1 },
        equipment = ["weapons/shortsword", "armor/padded_surcoat", "shields/wooden_shield"],
        bag = [],
        chapter = 1,
        encounterTitle = "请等第四下",
        encounterText = "白小帅子把鼓槌横在门闩上，刚数到第三下，阿飞就抢着接了一声好。她的手一抖，抬头盯着他，连旁边等着交班的人都憋住笑。鼓带的裂口用旧绳勉强系着，修补的报价已经说好，她却还没点头。眼下让她犹豫的还有另一个问题：跟这位团长走，以后究竟谁肯把第四下听完。",
        encounterChoices = [
            { label = "等她敲完四下，再复述约定的信号", outcome = "第四下落定，阿飞才开口。帅子听见信号被一字不差地说回来，愿意保留原价邀请；以后还会不会抢拍，她说得继续看。", cost = 0, hireDiscount = 0 },
            { label = "承担鼓带和门闩的修补费用", outcome = "约定的修补费用已付。帅子收好账纸，主动把招募报价压低了一些，邀请与优惠一并保留。阿飞还想接话，她举起鼓槌：别急，这次也得等第四下。", cost = 40, hireDiscount = 60 }
        ]
    },
    lili = {
        name = "李李超欧",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 260,
        wage = 10,
        background = "poacher_background",
        role = "弓箭与先手成长",
        description = "李李超欧很懂得让目光跟着自己走：一张高背椅，一次恰好的停顿，再把弓拿起来，原本打算散场的人就会多站一会儿。问得太没趣，她能转眼绕到别处；真有人拿成绩挑战她，她又会第一个回来。欧气是她喜欢挂在嘴边的说法，不妨碍偏了的箭仍要自己认。她愿意听黑旗能带来怎样的机会，却不会甘心只做招募告示上的招牌。想看超巨摆排场可以，最好也留一眼看她怎么出手。",
        attrs = [51, 96, 38, 115, 49, 51, 3, 5],
        stars = { RangedSkill = 2, Initiative = 1 },
        equipment = ["weapons/short_bow", "ammo/quiver_of_arrows", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 1,
        encounterTitle = "超巨这张椅子",
        encounterText = "李李超欧坐在高背椅上，脚边靠着弓，正等阿飞说这张椅子能不能上路。他还没想好，她已经绕到椅后，问他到底是来请超巨还是雇一个摆设。椅脚和弓弦各有一处待修，报价写在同一张纸上。她把纸压住，留给这位团长一个开口的机会；问得有趣，她倒愿意多听一句。",
        encounterChoices = [
            { label = "说想请会出手的超巨，让她开自己的条件", outcome = "她笑着把椅子让开，拿起靠在旁边的弓，说这句还算听得下去。原价邀请保留，她没有因此答应只替远征团摆出一副好看的架势。", cost = 0, hireDiscount = 0 },
            { label = "承担椅脚与弓弦的修整费用", outcome = "修整费用按报价付清。李李说这份捧场她收下了，给黑旗留下更低的招募报价；至于下一箭准不准，她说得等真正上场再看。", cost = 50, hireDiscount = 80 }
        ]
    },
    xiaoyueya = {
        name = "小月牙",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 240,
        wage = 9,
        background = "daytaler_background",
        role = "投掷与灵活换位倾向",
        description = "小月牙能把两块木板叫成超市，也能把一截断绳说成还差一点就够。她的主意常比解释快，前一句还在谈土豆，后一句已经拿木杆比划起棚顶。失败到了她手里，总得再被问一次还有没有别的用途。抹茶不肯盲信她的报价，她就兴致勃勃地逐样讲；阿飞觉得这人很有气氛，她却更关心黑旗行囊里有没有准备丢掉的铜扣。愿意招她同行的人，大概得习惯每天听到一声先别扔。",
        attrs = [52, 99, 36, 117, 48, 47, 4, 6],
        stars = { RangedSkill = 1, Initiative = 2 },
        equipment = ["weapons/javelin", "shields/buckler_shield", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 1,
        encounterTitle = "欢迎光临超市里",
        encounterText = "小月牙把两块木板一拍，招呼阿飞进超市里看看。牌子遮住了半张摊子，下面只摆着旧扣子、绳头和几块木片。抹茶刚问这些有什么用，她就把松掉的牌角卡回去，笑说现在看见一种了。招牌固定件的报价放在手边，她等着两位队长决定，是先听听另一种用法，还是替这间超市添点本钱。",
        encounterChoices = [
            { label = "挑一只旧铜扣，听她把古怪点子讲完", outcome = "小月牙拿铜扣演示了另一种扣法，接着又把它挂回招牌，笑问黑旗肯不肯带个有点子的人。邀请按原价留下，摊子上的每件旧东西仿佛都还有下一句要说。", cost = 0, hireDiscount = 0 },
            { label = "支付招牌固定件与旧工具的修整费用", outcome = "约定的修整费已付。小月牙乐呵呵地把招募报价往下改了一笔，优惠随邀请保留，还特意提醒抹茶回头核账，超市里可没有偷偷加一笔。", cost = 40, hireDiscount = 60 }
        ]
    },
    yuchujiu = {
        name = "余初九",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 280,
        wage = 10,
        background = "poacher_background",
        role = "九星核心：近攻、近防与先攻；灵活近战",
        description = "余初九的提醒很少拐弯，隔着一段路也能让人听清。阿飞兴头正高时，她可能是第一个打断他的人；真要清点回来的伙伴，她又会把队长的名字多确认一遍。有人拿她的大嗓门开玩笑，她通常连对方一起问：路看过了吗，人点齐了吗。忠诚在她这里包括当面说一句不行，也包括把话说完以后继续站在这面旗下。她愿不愿意同行，得看黑旗到底容不容得下一声响亮的喊停。",
        attrs = [53, 98, 46, 118, 50, 46, 5, 7],
        stars = { MeleeSkill = 3, MeleeDefense = 3, Initiative = 3 },
        equipment = ["weapons/throwing_axe", "shields/buckler_shield", "armor/thick_tunic", "helmets/hood"],
        bag = ["weapons/knife"],
        chapter = 1,
        encounterTitle = "听见就回一声",
        encounterText = "渡口边，余初九用船桨压住旧路图，问阿飞是否看清了角落的年份。他刚想解释近路，她先让他指一遍水位标记。河上风大，旁人嫌这话喊得太响，她连头都没回。新路图的核实费用还压在账页上，不过眼下她更想弄明白：这面黑旗想招的是一个肯开口的人，还是只会点头的影子。",
        encounterChoices = [
            { label = "把旧图收起，明确请她把危险说完", outcome = "阿飞没有再抢话，逐项确认了图上的危险。余初九移开船桨，保留原价邀请；等他准备走，又提高嗓门补了一句别把旧图拿错了。", cost = 0, hireDiscount = 0 },
            { label = "支付渡口路图的核实费用", outcome = "路图核实费用按报价付清。余初九记下这份帮助，报出更低的正式招募价，邀请与优惠保留；她仍要求团长往后听见喊停就回一声。", cost = 60, hireDiscount = 90 }
        ]
    },
    xiaoyubeike = {
        name = "小鱼贝壳",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 300,
        wage = 11,
        background = "daytaler_background",
        role = "九星核心：近攻、近防与生命；耐打的近战主力",
        description = "小鱼贝壳说话短，动作往往比话还快。栈桥外侧没人，她先把盾立过去；旁边有人握不住带子，她看一眼就知道。营里若用唯一的男人来夸她，她会把这句玩笑扔回去，问谁愿意下一次也顶上来。她能撑住一阵，却不会把喘气装成没事，那口先借来的劲总得慢慢还。她挑同伴不太听宏愿，主要看自己停下来换气时，旁边那个人会不会主动补上空位。阿飞也在这个考察范围里。",
        attrs = [64, 107, 40, 91, 53, 34, 6, 2],
        stars = { MeleeSkill = 3, MeleeDefense = 3, Hitpoints = 3 },
        equipment = ["weapons/bludgeon", "shields/wooden_shield", "armor/padded_surcoat"],
        bag = [],
        chapter = 1,
        encounterTitle = "空着的那一步",
        encounterText = "桥头两面旧盾摆在地上，小鱼贝壳用脚点了点外侧那一面。阿飞刚叫她一声可靠大哥，她便问这个称呼能不能替旁边再站一个人。桥上眼下没有争斗，只有松掉的扶绳和等人认领的修补账。她想听的不是一段保证，而是这位团长准备把自己放在哪个位置。等他说清，才轮到谈邀请。",
        encounterChoices = [
            { label = "站到她示意的位置，明说愿意轮换接应", outcome = "阿飞走到那一步，把轮换的约定说清。小鱼点点头，愿意保留原价邀请；两人都没再争那个大哥称呼，她只抬手纠正了他摆盾的位置。", cost = 0, hireDiscount = 0 },
            { label = "支付扶绳与盾带的修补费用", outcome = "修补费用按报价付清。小鱼看过收据，干脆报出更低的正式招募价，把优惠留给黑旗；钱能修好扶绳，往后站哪边仍得各自记住。", cost = 60, hireDiscount = 90 }
        ]
    },
    wangduidui = {
        name = "王怼怼",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 280,
        wage = 10,
        background = "militia_background",
        role = "决心与先攻较均衡",
        description = "王怼怼可能先被阿飞的嗓门吓一跳，再当着所有人的面把他问住。去哪儿、带什么、到地方等谁，这几个问题她不嫌重复，嫌的是每次都要靠自己猜。恐飞派与太子都是围绕这副反差闹起来的绰号，她却更看重手里那块能把话传清的牌子。给她一顶王冠，她会先找地方挂起来；给她一句确切的安排，她反而不怎么磨蹭。团长若想少听她怼一句，最好先把上一句说完整。",
        attrs = [54, 100, 47, 111, 54, 38, 5, 4],
        stars = { Bravery = 2, Initiative = 1 },
        equipment = ["weapons/militia_spear", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 1,
        encounterTitle = "太子不接糊涂口信",
        encounterText = "王怼怼把传令牌翻到背面，那里写着三个问题。阿飞刚把集合点说出两个版本，她已经停住脚步；旁人递来一顶歪王冠起哄，她随手挂上椅背，继续等那个答案。旧口信留下的凭据核对费还没人认领，她不急着接新活，只想看看黑旗这位团长是肯把话说全，还是准备再叫得响一点。",
        encounterChoices = [
            { label = "对着三个问题，把邀请与集合安排说完整", outcome = "阿飞逐项说完，怼怼才把牌子翻回来。她保留原价邀请，临了还补一句下次也照这样说；歪王冠继续挂在椅背，她根本没回头去拿。", cost = 0, hireDiscount = 0 },
            { label = "付清旧口信的凭据核对费用", outcome = "旧口信的核对费用已结清。王怼怼在招募报价旁写下更低的数，邀请与优惠一并保留，还不忘问阿飞这回的条件是不是已经说全。", cost = 50, hireDiscount = 80 }
        ]
    },
    laocai = {
        name = "老蔡",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 440,
        wage = 14,
        background = "militia_background",
        role = "稳健前排盾卫，近防、决心与生命成长",
        description = "老蔡谈加入时，先从桌上收起四枚木旗。他能把一条路拆成前进、接应和退回来的几种走法，讲到最坏的情况也不提高嗓门。阿飞嫌他想得太多，他就抽走一块代表桥梁的木块，让那个漂亮计划自己露出缺口。不过，最后留在险处的木旗背面写的是他自己的名字。他带着普通长柄武器上路，仍需在真实交锋里证明纸上的安排。队友可以指出图画错了，前提是把自己看见的那段路说明白。",
        attrs = [57, 103, 50, 100, 60, 39, 6, 4],
        stars = { MeleeDefense = 3, Bravery = 2, Hitpoints = 1 },
        equipment = ["weapons/boar_spear", "shields/wooden_shield", "armor/padded_surcoat", "helmets/aketon_cap"],
        bag = ["weapons/warfork"],
        chapter = 2,
        encounterTitle = "先抽掉这座桥",
        encounterText = "酒馆桌上摆着木旗和一截代表桥梁的木块。老蔡听完阿飞豪迈的安排，忽然抽走木块，让他看看留在另一岸的队尾。最后一面旗还扣着，翻过来，背面写的是老蔡自己。他提出两种谈法：一起把漏掉的情况说完，或分担这份推演需要的地形图查阅费。",
        encounterChoices = [
            { label = "把队尾和接应的位置讲清，再谈雇用", outcome = "两人把不同的判断留在图上，没有强行说成同一个答案。老蔡愿意按原报价加入，接受队友当面指出方案的漏洞。", cost = 0, hireDiscount = 0 },
            { label = "分担地形图查阅费，换取招募优惠", outcome = "地形图的查阅费用由远征团分担。老蔡把这项支持折入招募优惠；那块代表桥梁的木块，仍被他留在桌边。", cost = 70, hireDiscount = 100 }
        ]
    },
    tiantong = {
        name = "亿口甜筒",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 340,
        wage = 11,
        background = "poacher_background",
        role = "稳定弓手与决心成长",
        description = "大家喊她小虎，她答应时已经把信袋的封口检查了一遍。袋底那封皱信，是她还没答应算完的事。驿站愿意给钱，掌柜甚至把回执提前盖好，她却只问东西究竟落在谁手里。阿飞听久了有些头大，也记住了她分得很清的两个词：快，和到。她带普通弓箭同行，走出一段还会看看队尾。要她临时改变约定，可以商量；要她把没交清的事说成已经办妥，她会把那张纸重新推回来。",
        attrs = [52, 97, 45, 109, 48, 55, 3, 6],
        stars = { RangedSkill = 2, Bravery = 1 },
        equipment = ["weapons/hunting_bow", "ammo/quiver_of_arrows", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 2,
        encounterTitle = "盖好印也不算送到",
        encounterText = "亿口甜筒面前放着一张盖好印的空回执，袋底的信却还没有新地址。掌柜催她先领钱，她把回执压在桌上，问阿飞愿不愿意先听清这件未完成的事。她想找个能容许核实去向的队伍；若有人分担驿站查档费，加入时的报价也可以重新谈。",
        encounterChoices = [
            { label = "接受先核实去向的约定，按原价谈邀请", outcome = "小虎把未送达写在回执上，再把雇用条件说清。她愿意按原报价加入；那封信的后续去向仍需另行安排。", cost = 0, hireDiscount = 0 },
            { label = "分担驿站查档费，换取招募优惠", outcome = "查档费用得到支持，她相应降低了招募报价。回执上仍写着未送达，付这笔钱没有让一件未完成的事凭空完成。", cost = 50, hireDiscount = 80 }
        ]
    },
    xiaoning = {
        name = "小宁",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 390,
        wage = 12,
        background = "poacher_background",
        role = "远攻与远防偏好的弩手",
        description = "小宁的外号是外星人，看她摊开一张地图就不难明白为什么。她能一本正经地把河画成面饼，再省略掉别人最想知道的那半句；想得入神，嘴角还会留下一点口水。阿飞常被她突然冒出的回答噎住，小月牙却很爱替她的符号起名字。她不是每次都藏着高明答案，有时确实把自己也绕了进去。不过，问明白她究竟从哪一步开始想，往往又能看见一条不同的路。远征团的公用地图如今得先交两个人看过。",
        attrs = [51, 95, 41, 104, 50, 58, 4, 8],
        stars = { RangedSkill = 2, RangedDefense = 1 },
        equipment = ["weapons/light_crossbow", "ammo/quiver_of_bolts", "armor/padded_surcoat"],
        bag = ["weapons/knife"],
        chapter = 2,
        encounterTitle = "先说这个圆圈是什么",
        encounterText = "小宁的路图缺了一角，城名被口水洇开，河道又画得像面饼。阿飞喊她外星人，她擦擦嘴，指着圆圈先说起晚饭。小月牙已经看中了这套记号，抹茶赶紧收好账本。地图铺能补抄一份图，价钱就压在纸边；不过在那之前，总得有人听懂她是从哪里开始画的。",
        encounterChoices = [
            { label = "请她从第一个怪符号讲起", outcome = "两人终于把河和吃饭的地方分开。小宁在图角补了一句别人看得懂的话，留下原价邀请，又顺手给阿飞的旗子添上两条腿。", cost = 0, hireDiscount = 0 },
            { label = "支付缺页路图的补抄费用", outcome = "补抄费用结清，小宁把新纸卷好，给出较低的招募报价。至于那套面饼与圆圈的记号，她说还是想留一份。", cost = 60, hireDiscount = 90 }
        ]
    },
    xiaopangxu = {
        name = "小胖徐不快乐",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 400,
        wage = 12,
        background = "militia_background",
        role = "耐力与近防偏好的盾斧配置",
        description = "小胖徐听见节拍，脚下就先有了回应。她的街舞讲究卡拍和转身，空桶倒地的声音也能被顺手接进下一拍。阿飞曾拿嘉豪步伐跟她比划，白小帅子负责敲鼓，旁边的人负责笑；可真举起盾牌，她自己也会被重量带歪。她不急着藏住失误，总要把那一步拆开，再踩一次。对她来说，热闹和练本事可以在同一块地上发生。哪天鼓点停了还听见门口有人磨鞋底，多半是她还没满意。",
        attrs = [62, 110, 42, 92, 57, 33, 8, 3],
        stars = { Stamina = 2, MeleeDefense = 1 },
        equipment = ["weapons/hand_axe", "shields/wooden_shield", "armor/padded_surcoat"],
        bag = [],
        chapter = 2,
        encounterTitle = "那只桶正好倒在第四拍",
        encounterText = "白小帅子的鼓声从酒馆角落传来，小胖徐刚转半圈，阿飞的嘉豪步伐就撞倒了空桶。她把那声响接进下一拍，让笑得最响的团长再试一次。掌柜随后送来清单：腾场的租费和磨损木板的修整费还没结。黑旗要邀她同行，可以先聊聊这套步子，也可以替她结下这笔开销。",
        encounterChoices = [
            { label = "跟着节拍再试一次，谈原价邀请", outcome = "阿飞这回在桶边收住脚，小胖徐笑着敲了第四拍。她愿意按原报价加入，约好以后有鼓声时再比谁先乱步。", cost = 0, hireDiscount = 0 },
            { label = "分担练习场地与地板修整费", outcome = "场租和地板修整费结清，小胖徐下调招募报价。她把空桶摆回角落，给阿飞留出一块不容易撞上的地方。", cost = 70, hireDiscount = 100 }
        ]
    },
    dae = {
        name = "大鹅",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 370,
        wage = 11,
        background = "militia_background",
        role = "守位前排盾卫，近防、决心与生命成长",
        description = "有人，这两个字能被大鹅喊得整间酒馆都听见。凳上明明只有一顶帽子，她却能把去打水的同伴说得像正坐在面前。身后是自己人，她就有了十足的底气；有人挤过来，她也不急着把边界让掉。阿飞若只看见她敢冲，很容易跟着起哄，等她突然转身先让同伴进门，才发现她一直记着谁还没回来。她带着长矛和木盾上路，嗓门替不了真正的防守；想守住那一小块属于大家的地方，还得有人和她一起站。",
        attrs = [61, 103, 46, 94, 55, 35, 9, 3],
        stars = { MeleeDefense = 3, Bravery = 2, Hitpoints = 1 },
        equipment = ["weapons/militia_spear", "shields/wooden_shield", "armor/padded_surcoat", "helmets/hood"],
        bag = [],
        chapter = 2,
        encounterTitle = "帽子在，人就有位置",
        encounterText = "长凳上只有一顶帽子，大鹅却坚持那儿有人。阿飞刚想逗她，外出打水的同伴就挤到门边，她把挡路的椅子拨开，先让人坐下。现在她问黑旗招人后算不算自己人：可以先把营地里的规矩讲清，也可以分担她离开旧营位前尚未结清的席位与茶水账。",
        encounterChoices = [
            { label = "把入队后的共同规矩讲清，按原价邀请", outcome = "大鹅听清了共同规矩，愿意按原报价加入。她把帽子交回同伴手里；入队的邀请有了，正式雇用仍需另谈。", cost = 0, hireDiscount = 0 },
            { label = "结清旧营位的席位与茶水账", outcome = "旧营位的席位与茶水账结清，大鹅下调招募报价。她先让同伴把帽子收好，才转头继续跟阿飞谈黑旗的位置。", cost = 50, hireDiscount = 80 }
        ]
    },
    manyuemei = {
        name = "蔓越莓",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 410,
        wage = 12,
        background = "poacher_background",
        role = "远攻与先攻兼顾",
        description = "蔓越莓把红线往桌上一拉，阿飞就知道这次没法靠热闹混过去。停、坐下、再说一遍，她的句子短，留给别人抢话的缝也小。她喜欢把混乱的局面攥回自己的节奏里，尤其不耐烦一个问题还没答完，对方又开始讲漂亮话。不过，那枚被她漏看的木片让大谋点出来时，她照样当场更正。强势不必靠装作永远正确来维持。她拿着一把轻弩，箭袋上也系着一截红线，提醒同伴先看清彼此的位置；阿飞想要她服气，得拿出同样清楚的决定。",
        attrs = [50, 99, 44, 116, 47, 56, 4, 7],
        stars = { RangedSkill = 2, Initiative = 2 },
        equipment = ["weapons/light_crossbow", "ammo/quiver_of_bolts", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 2,
        encounterTitle = "先把顺序说一遍",
        encounterText = "蔓越莓用红线把桌面划开，让阿飞依次说谁前进、谁等待。每当他想插一句夸耀，她就敲一下桌面，叫他先回答眼前的问题。她也接受队友指出漏算的地方。邀请她之前，可以把这种讨论规矩说定；也可以分担她借用推演场地的费用，重谈招募价。",
        encounterChoices = [
            { label = "接受把问题逐项说清，按原价谈邀请", outcome = "阿飞把最后一个问题答完，蔓越莓才松开红线。她愿意按原报价加入；明确说话的规矩，不等于谁从此不能提出异议。", cost = 0, hireDiscount = 0 },
            { label = "分担推演场地费用，换取招募优惠", outcome = "场地费用得到支持，蔓越莓给出招募优惠。她让阿飞把双方刚谈好的条件再说一遍，确认这次确实听明白了。", cost = 60, hireDiscount = 90 }
        ]
    },
    xiaohani = {
        name = "小哈尼",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 330,
        wage = 10,
        background = "daytaler_background",
        role = "近攻与先攻偏好的轻装配置",
        description = "小哈尼把旧海图折得很小，谈报酬时也会放在桌边。招工的人爱用以后来劝她，阿飞更擅长把以后说得热闹，她却总能把话问回眼下要去的那一站。她并非非走最快的路不可，也知道旅费得一份份挣；只是不愿一季接着一季，到头来还没开始自己的行程。她带一把普通弯刀来谈加入，希望把这段同行的条件说清楚。名声可以慢慢有，目标也可以重新考虑，至少这张属于她自己的地图，不用先替别人收起来。",
        attrs = [53, 102, 39, 119, 54, 43, 5, 6],
        stars = { MeleeSkill = 1, Initiative = 2 },
        equipment = ["weapons/falchion", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 2,
        encounterTitle = "下一站叫什么",
        encounterText = "小哈尼正把旧海图折进行囊，几个招工人都向她保证以后会去海边。阿飞才开口讲远征团的将来，她就问眼下要去哪里。她愿意接活攒旅费，但不想先答应一整年。两人可以先说清当前的雇用条件，也可以由黑旗分担她向地图铺查阅沿途路账的费用。",
        encounterChoices = [
            { label = "只谈眼下能兑现的雇用条件，按原价邀请", outcome = "这次谈话没有把一个以后说成已经定好的旅程。小哈尼愿意按原报价加入，关于海边的想法仍留给往后商量。", cost = 0, hireDiscount = 0 },
            { label = "分担沿途路账查阅费，换取招募优惠", outcome = "查阅路账的费用得到支持，她相应降低招募报价。关于去海边的想法，双方约定留到往后再谈，她把自己的地图仔细收好。", cost = 40, hireDiscount = 60 }
        ]
    },
    keke = {
        name = "可可",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 420,
        wage = 13,
        background = "poacher_background",
        role = "鼓舞同伴的前排盾卫，近防与决心成长",
        description = "可可认出朋友时，往往先腾位置，再问有没有吃过东西。热心起来，连刚见面的人也容易被她招进自己人的圈。保可梦的守望落在具体的小事上：有人想往前，她先看侧后还有谁。她能接受同伴冒险，却不喜欢一句有你在就把所有后果塞过来。黑旗吸引她的地方，是这些大嗓门的人既能把席间吵热，也似乎肯停下来听提醒。她愿不愿留下，要看这份亲近能否长成双方都接得住的承诺。",
        attrs = [55, 100, 48, 103, 52, 54, 6, 6],
        stars = { MeleeDefense = 3, Bravery = 2, Stamina = 1 },
        equipment = ["weapons/boar_spear", "shields/wooden_shield", "armor/padded_surcoat"],
        bag = ["weapons/knife"],
        chapter = 3,
        encounterTitle = "布条上没有名字",
        encounterText = "可可已经替黑旗留好位置，又把一名无处落座的搬运工招到桌边。她想帮忙把交接谈妥，也想听听同行的安排。手边那张弩具整修单还没付清：若黑旗愿意分担这笔列明的费用，她可以把正式招募的报价降一些；不分担，也不耽误先坐下来聊。",
        encounterChoices = [
            { label = "一起认清来人，保留原价邀约", outcome = "几个人把去处逐个问清，可可仍给黑旗留着座位。双方保留原价招募条件，热心不用先换成欠账。", cost = 0, hireDiscount = 0 },
            { label = "分担弩具整修费，商定招募优惠", outcome = "黑旗承担了约定的整修费用，可可随即调低招募报价。她把话说在前头：这笔记清楚，人还得一个个认识。", cost = 70, hireDiscount = 100 }
        ]
    },
    yuxiang = {
        name = "余想",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 400,
        wage = 12,
        background = "militia_background",
        role = "长柄武器与持续站位",
        description = "余想听过许多赞词，最警觉的一句是你最让人放心。那通常意味着有人准备把自己的班也交给她。五老压阵的名号很响，她却更在意长矛稳不稳、交接清不清楚、下岗时有没有人到场。她开口能把热闹压下来，冷脸里常藏着一句不肯白吃亏的玩笑。阿飞想请她守住队伍，她想确认队里还有别人会守。与审查情报的余初九不同，她站定的是既定岗位，等的是下一班具体的人。",
        attrs = [59, 108, 49, 97, 58, 35, 7, 4],
        stars = { Stamina = 1, MeleeDefense = 1, Bravery = 2 },
        equipment = ["weapons/pitchfork", "armor/padded_surcoat", "helmets/hood"],
        bag = ["weapons/knife"],
        chapter = 3,
        encounterTitle = "空着的替班栏",
        encounterText = "余想终于让旧哨所的掌事签了交接，正准备另找落脚处。大谋提出黑旗的邀请，她先看轮值，再看旅店寄存行李的账单。按原价招募，她自己处理这笔；若黑旗愿意按列明费用分担，招募价便可再议。她只强调一次：别把补贴写成又多守一班。",
        encounterChoices = [
            { label = "尊重她的交班安排，原价留邀约", outcome = "余想收好交班簿，接受原价邀约，准备按自己的顺序处理行李。大谋笑说，至少这回没人在门口假装听不见她下岗。", cost = 0, hireDiscount = 0 },
            { label = "分担寄存费，议定招募优惠", outcome = "寄存费用按约分担，余想相应降低招募报价。抹茶特意把补贴与轮值分开记，她对此很满意。", cost = 60, hireDiscount = 90 }
        ]
    },
    tongzhu = {
        name = "童猪",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 320,
        wage = 10,
        background = "daytaler_background",
        role = "生命与决心较有潜力",
        description = "童猪能把一只木熊摆出审判官的威严，又在别人自信猜错时笑得险些忘记敲杯。她喜欢热闹，尤其喜欢把几位互不服气的人拉到同一张桌边。小熊出击之前先懂规则，听起来是提醒，也带一点等你出糗的坏心眼。她接受质疑玩法，不接受输掉以后偷偷修改已经发生的那一步。黑旗有三位格外适合坐上游戏桌的队长。至于要不要同行，她既看待遇，也想知道下一次会是谁第一个抢答。",
        attrs = [58, 98, 50, 107, 51, 40, 5, 4],
        stars = { Hitpoints = 1, Bravery = 2 },
        equipment = ["weapons/wooden_stick", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 3,
        encounterTitle = "再讲一遍，还是先认输",
        encounterText = "抹茶和大谋还在争刚才哪一步开始算错，童猪把小熊翻过来，请他们看底下的规则。掌柜另摆来一张场地费单。她愿意考虑黑旗的邀请：保留原价，也可由黑旗分担列明的场租换取招募优惠。付钱只解决场地，桌上输掉的那一局谁也别想删。",
        encounterChoices = [
            { label = "认输再听规则，保留原价邀约", outcome = "两位队长终于认下这一局，童猪笑着保留原价邀约。她觉得黑旗值得考虑，尤其适合给小熊增加一点见识。", cost = 0, hireDiscount = 0 },
            { label = "分担游戏桌场租，议低招募价", outcome = "约定的场租结清，童猪相应降低招募报价。她把木熊转向两位队长，宣布钱算完了，输赢还照原来的算。", cost = 40, hireDiscount = 70 }
        ]
    },
    meiya = {
        name = "美伢",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 430,
        wage = 12,
        background = "militia_background",
        role = "近攻、耐力与先攻均衡",
        description = "美伢记得鼓点前的一口气，也记得台侧哪块木板会让人绊倒。大王舞听起来像在奉承场上的主角，她却最清楚主角该在哪一拍让路。阿飞以为招来的是能把场面炒热的人，她想谈的是谁能决定场面怎样排。她会把问题指到具体的一步、一把盾、一个堵住的位置，懒得接受空泛的天赋夸奖。与黑旗同行的理由，是把这种判断力带出宴厅，看看能不能得到同样认真的报酬和信任。",
        attrs = [56, 105, 45, 112, 58, 39, 6, 4],
        stars = { MeleeSkill = 1, Stamina = 1, Initiative = 1 },
        equipment = ["weapons/warfork", "armor/padded_surcoat"],
        bag = ["weapons/knife"],
        chapter = 3,
        encounterTitle = "请团长走过这两把椅子",
        encounterText = "美伢与鼓手还在争刚才那半拍，争完又一起看断掉的鼓带。她对黑旗的邀请有兴趣，想谈的是完整负责行动的机会。原价邀约可以留下；若黑旗按列明费用补贴鼓带修理，她也愿意降低招募报价，把这场临时救场留下的账先理清。",
        encounterChoices = [
            { label = "听她谈主位与合作，原价邀约", outcome = "美伢把想负责的事说清，接受留下原价邀约。鼓手在旁边补了一句别又抢拍，她回敬的眼神倒没有什么火气。", cost = 0, hireDiscount = 0 },
            { label = "补贴鼓带修理，议低招募价", outcome = "鼓带修理费按约分担，美伢相应降低招募报价。她感谢这份支持，也表示真正同行后还想再谈自己的位置。", cost = 60, hireDiscount = 100 }
        ]
    },
    wanshe = {
        name = "玩蛇",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 420,
        wage = 12,
        background = "militia_background",
        role = "近攻与先攻偏好的单手剑配置",
        description = "玩蛇给招式起的名字很响，检验招式时却喜欢问一个很小的问题：你是从哪一步开始站不住的？木桩上的蛇痕记着反复改过的路线，秦国的神是招牌，也是别人等着看笑话的理由。她并不准备因此闭嘴，更想找些敢拿不同办法来碰一碰的人。大谋的省力办法让她不服，又确实值得再试；阿飞能安静数清次数时，也算有用。她对黑旗的兴趣，就从这场还没分出谁更懂的争论开始。",
        attrs = [54, 102, 41, 114, 59, 36, 7, 5],
        stars = { MeleeSkill = 2, Initiative = 1 },
        equipment = ["weapons/shortsword", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 3,
        encounterTitle = "先别讲，把脚放这里",
        encounterText = "玩蛇与大谋把两只桶搬来搬去，各执一套试招的理由。看场人递来追加场租，两人这才发现旁观者已经换了一拨。黑旗可以原价留下邀请，也能按列明费用分担场租，换取较低招募报价。玩蛇只问大谋一句：真同行以后，这个还接着试不试？",
        encounterChoices = [
            { label = "约好继续试招，原价邀请同行", outcome = "大谋答应有空接着争，玩蛇便留下原价招募条件。她把木剑往肩上一搁，显然已开始琢磨下一个难题。", cost = 0, hireDiscount = 0 },
            { label = "分担试招场租，议低招募价", outcome = "试招场租按约结清，玩蛇降低招募报价。她还记着大谋欠她的一句解释，钱可没把那场争论买断。", cost = 60, hireDiscount = 90 }
        ]
    },
    tutu = {
        name = "涂涂",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 310,
        wage = 10,
        background = "daytaler_background",
        role = "决心与耐力偏好的轻装起步",
        description = "涂涂随身带着下一站的打算，也可能因为营火边一个接不上的笑话，又多坐一会儿。她并不把每次回头都解释成命运，再留一晚有时只是自己愿意。同行可以是真心，告别也不一定是谁负了谁。她想找的是能谈清一段路的伙伴，不是非得先许诺永远才能坐下的营地。黑旗三位队长未必总说得明白，吵闹间倒有些值得听完的东西。她会决定自己的去处，也肯让喜欢的人知道自己为什么选择它。",
        attrs = [52, 104, 52, 106, 50, 42, 4, 5],
        stars = { Bravery = 2, Stamina = 1 },
        equipment = ["weapons/lute", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 3,
        encounterTitle = "这一段，先写清楚",
        encounterText = "涂涂回来取手套，主动问起黑旗下一程的方向。她的路票还有效，换个打算也有一笔列明的改签费用。原价邀请可以先留着，让她自己比较；若黑旗愿意承担改签开支，她会相应降低招募报价。无论哪种谈法，下一段去处仍由她决定。",
        encounterChoices = [
            { label = "给她自己选择的余地，原价邀约", outcome = "涂涂保留路票，也保留黑旗的原价邀请。她又坐稳了一点，开始谈自己想走的那条路。", cost = 0, hireDiscount = 0 },
            { label = "分担路票改签费，议低招募价", outcome = "改签开支按约分担，涂涂降低招募报价。她感谢这份支持，至于正式同行，双方仍等招募时把这一段说定。", cost = 40, hireDiscount = 60 }
        ]
    },
    songnuanyang = {
        name = "宋暖阳",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 320,
        wage = 10,
        background = "daytaler_background",
        role = "生命、近攻与决心均衡",
        description = "被叫作鹌鹑的宋暖阳，听到响动时偶尔收一下颈，片刻后又会探头把问题问完。告示摊上可以听见许多凯旋，真正值得落笔的却不总是最响亮的那份。黑旗眼下没有多少漂亮战绩，倒有不少值得继续听下去的争执。若同行，宋暖阳想保留那些不好归类的片段：有人嘴硬，有人走开，也有人被一句认真回答留住。故事未必每次都能有漂亮结尾，但这份不确定，正是跟上去看看的理由。",
        attrs = [57, 101, 46, 104, 52, 39, 4, 4],
        stars = { MeleeSkill = 1, Bravery = 1, Hitpoints = 1 },
        equipment = ["weapons/militia_spear", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 4,
        encounterTitle = "所向无敌，从哪一场写起",
        encounterText = "雇主留下半份纸墨钱便离开，宋暖阳把那张假凯旋告示翻了面。黑旗的邀请听来还算有趣：至少这三个人没把争吵藏好。原价招募可以谈；若黑旗按列明费用补贴纸墨开支，报价也可降低。摊外锣响，鹌鹑收颈又探头，等三位队长说打算。",
        encounterChoices = [
            { label = "邀请记录沿途真事，保留原价", outcome = "宋暖阳接受留下原价邀请，准备再听听黑旗的故事。阿飞指着乱草稿说这里全是真事，鹌鹑的笔终于动了动。", cost = 0, hireDiscount = 0 },
            { label = "补贴纸墨开支，商定招募优惠", outcome = "纸墨开支按约补贴，宋暖阳相应降低招募报价。那张凯旋告示仍旧翻着面，黑旗并没有顺手买下一首赞歌。", cost = 40, hireDiscount = 60 }
        ]
    },
    xiaogui = {
        name = "溺水小龟",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 350,
        wage = 11,
        background = "daytaler_background",
        role = "前排盾卫，近防与决心成长；保留投掷副手",
        description = "溺水小龟坐上木箱才够得着棋盘，却一定要把写着自己名字的牌子摆到最显眼处。他叫飞爹时带着亲近，也藏着一点较劲：既然大哥有值得讲的战绩，他也想拿出属于自己的那一场。阿飞的关注会让他高兴，可手伸到棋盘上代走一步就不行。小龟愿意听意见，更希望意见能留给自己作决定的余地。若加入黑旗，他要的不是永远被带着走，而是有朝一日能把牌推到阿飞面前，说这一局请你坐下来看看。",
        attrs = [55, 106, 45, 103, 50, 46, 6, 9],
        stars = { MeleeDefense = 3, Bravery = 2, Stamina = 1 },
        equipment = ["weapons/boar_spear", "shields/wooden_shield", "armor/thick_tunic"],
        bag = ["weapons/javelin"],
        chapter = 4,
        encounterTitle = "飞爹先坐观众席",
        encounterText = "小龟把阿飞的手轻轻挡在棋盘外，请他先当观众，再当教练。他想报名一场自己的比试，列明的参赛开支还没结清。黑旗可以原价留下邀请，也能分担这笔费用，换取较低招募报价。小龟都愿意考虑，但棋子仍由他自己决定怎么走。",
        encounterChoices = [
            { label = "支持他独立试一场，原价邀约", outcome = "阿飞把手收回，答应有机会认真看他的比试。小龟接受原价邀约，随即又盯回自己的路线；结果得等他自己走出来。", cost = 0, hireDiscount = 0 },
            { label = "分担参赛开支，议定招募优惠", outcome = "参赛开支按约分担，小龟相应降低招募报价。他笑着给飞爹指了指观众的位置，资助可不包含代他下棋。", cost = 50, hireDiscount = 80 }
        ]
    },
    naigai = {
        name = "奶盖",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 280,
        wage = 9,
        background = "daytaler_background",
        role = "近防与投掷有潜力的新手",
        description = "奶盖说起胜负，仿佛全天下的教官都该先排队听她讲完。真正把盾拿到手上，话却可能比手快上三拍。嘴强王者一缩进奶盖，仍会从盾后补出半篇解释，抽象整活让尴尬很难安静落地。她不想只当队伍的笑料，也不肯因为一次出糗就从台上消失。阿飞对这种嘴硬并不陌生，笑完也愿意把招募纸继续留着。她究竟有没有下一步本事尚待再看，至少本王考虑考虑这句，已经被她讲得像真的一样。",
        attrs = [54, 99, 35, 110, 48, 44, 4, 3],
        stars = { RangedSkill = 1, MeleeDefense = 2 },
        equipment = ["weapons/throwing_axe", "shields/buckler_shield", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 4,
        encounterTitle = "盾后面还有一句",
        encounterText = "奶盖躲在立歪的盾后解释自己是在研究对手，随后悄悄看了一眼磨破的盾带。她想把下一次试训的准备做好，又不肯先收回本王的名号。黑旗可原价留下招募条件，也可按列明费用补贴盾带修理，换取招募优惠。笑归笑，认真邀约她还是想听。",
        encounterChoices = [
            { label = "给她认真再试的机会，原价邀约", outcome = "阿飞愿意听她想练什么，奶盖立即声称早有安排。双方保留原价招募条件，谁也没再撤掉那张纸。", cost = 0, hireDiscount = 0 },
            { label = "补贴盾带修理，议低招募价", outcome = "盾带修理费按约补贴，奶盖降低招募报价，又宣布这叫英雄之间互相成全。大谋点头，暂时没拆穿她的心虚。", cost = 40, hireDiscount = 60 }
        ]
    },
    xiaojie = {
        name = "小杰",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 320,
        wage = 10,
        background = "daytaler_background",
        role = "耐力与生命偏好的近战配置",
        description = "小杰喜欢把锁扣听到清楚的一声响，再转身办下一件事。她对大概会还、大家都认识这类担保尤其不买账，认真起来连空箱子的锁也不肯先卸。锁车是办法，不上这个当是口头的决心；备用钥匙却让她开始考虑，规矩能不能让自己少跑几趟。她与抹茶谈借据时很有兴致，谈到借而不还的熟人又马上板起脸。若加入黑旗，她想减少的不是热闹，而是热闹散后人人指向别处的那笔糊涂账。",
        attrs = [60, 109, 41, 99, 53, 37, 5, 4],
        stars = { Stamina = 2, Hitpoints = 1 },
        equipment = ["weapons/pickaxe", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 5,
        encounterTitle = "未来团长，现在哪位担保",
        encounterText = "小杰终于查清绳钩借给了谁，正和抹茶讨论怎样不必每次都由她开锁。锁匠已经列好补配备用钥匙的费用。黑旗可以原价留下招募邀请，也可分担这笔开支，换取较低报价。她把账单摆正，强调讨论的是分工，别顺手把她全部钥匙要走。",
        encounterChoices = [
            { label = "讨论分工与借还，原价留邀约", outcome = "抹茶与小杰把借还办法谈得有来有回。她保留原价招募条件，觉得黑旗里至少有人愿意认真听锁之外的问题。", cost = 0, hireDiscount = 0 },
            { label = "分担配钥匙费，议定招募优惠", outcome = "配钥匙费用按约分担，小杰相应降低招募报价。她把这笔单独记清，表示这才像一场以后不必互相翻旧账的邀约。", cost = 50, hireDiscount = 80 }
        ]
    },
    bula = {
        name = "bula",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 330,
        wage = 10,
        background = "daytaler_background",
        role = "生命、决心与远防均衡",
        description = "bula 很清楚一只钱袋怎样显得鼓，也清楚热闹散场后里面究竟剩多少。她配合戏法时能让观众笑，摊账时也能笑着把对方不想听的数字报完。抹茶会问账能不能平，她会继续问买回来的东西是否有人用得顺。好看的计划并不令她反感，她只是讨厌账单出现时，众人忽然都把目光挪开。黑旗若想请她照看公用开支，就得让采买的决定同样公开，别等袋底见空才想起谁最会算。",
        attrs = [56, 102, 47, 101, 51, 42, 5, 6],
        stars = { Bravery = 1, RangedDefense = 1, Hitpoints = 1 },
        equipment = ["weapons/bludgeon", "shields/wooden_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 5,
        encounterTitle = "这枚铜片付不了粮钱",
        encounterText = "bula 把戏法道具币拨到一边，桌上还有列明的道具布料费用未结。她愿意听黑旗的采买打算，原价邀约可以保留；若黑旗分担这笔演出开支，她也会降低招募报价。阿飞摸了摸那枚薄铜片，终于明白台上消失的钱和台下缺的钱是两回事。",
        encounterChoices = [
            { label = "共同核对采买需要，保留原价", outcome = "bula 和抹茶把采买思路对过一遍，愿意接受原价邀约继续商量。道具币仍躺在桌角，专门留着提醒团长别把掌声当预算。", cost = 0, hireDiscount = 0 },
            { label = "分担道具布料费，议低招募价", outcome = "道具布料费用按约分担，bula 相应降低招募报价。她把支持与优惠都写明，既不欠含糊人情，也不让钱袋凭空变厚。", cost = 50, hireDiscount = 80 }
        ]
    },
    suwa = {
        name = "苏袜",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 370,
        wage = 11,
        background = "poacher_background",
        role = "高先攻与耐力倾向",
        description = "苏袜喜欢快，连解释一条路时都像已经迈出下一个路口。踩点、抢半步、看准情形急刹，她对落脚的变化十分敏感。她知道许多旁人不会注意的地方，却未必习惯把它们说成别人也能照走的路线。车夫的反问令她不服，车轮留下的印子又让问题变得很具体。她愿意考虑黑旗，既想继续发现新路，也想让领路的人得到应有的话语权，而不只是每次散场后再被喊去跑一趟。",
        attrs = [51, 105, 40, 124, 51, 48, 5, 7],
        stars = { Initiative = 3, Stamina = 1 },
        equipment = ["weapons/javelin", "shields/buckler_shield", "armor/thick_tunic"],
        bag = ["weapons/knife"],
        chapter = 5,
        encounterTitle = "到底是哪只靴子",
        encounterText = "苏袜和车夫对着同一条近路各说各话，最后决定把快脚路线与车行路线分别画清。抄图铺已报出重绘标记的费用。黑旗可以原价留下邀请，也能按列明费用分担补图，换取招募优惠。她伸手指着岔口，仍坚持先把两条路究竟适合谁讲完。",
        encounterChoices = [
            { label = "听完两条路的区别，原价邀约", outcome = "苏袜把两条路说清，接受留下原价邀约。车夫总算不再摇头，她也觉得这次停下来解释并不白费。", cost = 0, hireDiscount = 0 },
            { label = "分担补图费用，议低招募价", outcome = "补图费用按约分担，苏袜相应降低招募报价。她满意地点头，提醒阿飞，付钱以后也得肯听路况。", cost = 60, hireDiscount = 90 }
        ]
    },
    qianhan = {
        name = "千涵",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 350,
        wage = 11,
        background = "militia_background",
        role = "近攻与近防偏好的长矛与盾牌配置",
        description = "千涵把003号木牌擦得很亮，哪怕知道它只是排队顺序，也舍不得让编号蒙灰。她会认真练习，认真比较谁先跑过那段坡，也会因别人夸得太远而着急解释。短坡冲刺需要留力，分段呼吸则让她把很长的目标拆成一段一段。她想证明自己，并不满足于永远当一个值得鼓励的新手；只是传奇要怎么写，得等自己真的做完。黑旗若肯给这份较劲留出位置，下一程便值得考虑。",
        attrs = [55, 103, 43, 106, 55, 38, 6, 4],
        stars = { MeleeSkill = 2, MeleeDefense = 1 },
        equipment = ["weapons/militia_spear", "shields/wooden_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 5,
        encounterTitle = "别替003写得太快",
        encounterText = "千涵又把003木牌擦了一遍，指着练习纸说明下一段想练到哪里。场边木桩与标距绳需要租用，费用已列明。黑旗可原价留下邀请，让她自己安排这笔，也可分担练习场具的开支换取招募优惠。她期待的是继续进步，不急着把编号变成传奇称号。",
        encounterChoices = [
            { label = "支持她自己的进度，原价邀约", outcome = "千涵收好原价招募条件，继续把眼前的目标写实在。阿飞这回没抢着替她命名，003木牌仍被她摆在最亮的位置。", cost = 0, hireDiscount = 0 },
            { label = "分担场具租费，议定招募优惠", outcome = "场具租费按约分担，千涵相应降低招募报价。她认真道谢，也表示接下来那一段还是要靠自己完成。", cost = 50, hireDiscount = 80 }
        ]
    },
    wangdazhi = {
        name = "王大芷",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 400,
        wage = 12,
        background = "militia_background",
        role = "近防、耐力和决心偏好的持盾起步",
        description = "旁人有时叫王大芷，有时仍顺口喊芷芷，她应声之前往往已经看见哪根架子在晃。她懂得撑住幕布、摆稳架脚、把门口留给该过去的人；事情一乱，别人便自然向她招手。站稳场子是本事，也容易让她自己的登场被一推再推。那张写着名字的纸条，她其实记得比谁都清楚。若考虑黑旗，她可以谈护场的责任，也想谈自己打算做的事，不能换一面旗以后，又成为永远腾不出手的那个人。",
        attrs = [58, 106, 48, 98, 54, 35, 8, 5],
        stars = { MeleeDefense = 2, Stamina = 1, Bravery = 1 },
        equipment = ["weapons/wooden_flail", "shields/wooden_shield", "armor/padded_surcoat"],
        bag = [],
        chapter = 5,
        encounterTitle = "谢幕名单漏了谁",
        encounterText = "王大芷终于放开幕布架脚，却发现自己的登场已被排到散席以后。她正在和掌事商量下一场，手边还压着裂口幕布的修补账单。黑旗可以原价留下邀请，也可按列明费用分担修补，换取招募优惠。她请三位队长先听打算，别又只问谁来撑架子。",
        encounterChoices = [
            { label = "听她自己的登场计划，原价邀约", outcome = "三位队长听完她的打算，王大芷留下原价招募条件。这回她名字旁边写的是想做的事，不只是哪根架子归她看。", cost = 0, hireDiscount = 0 },
            { label = "分担幕布修补费，议低招募价", outcome = "幕布修补费按约分担，王大芷相应降低招募报价。她感谢支持，也没有因此收回为自己争取登场的打算。", cost = 70, hireDiscount = 100 }
        ]
    },
    yaoyaoya = {
        name = "瑶瑶牙",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 450,
        wage = 13,
        background = "militia_background",
        role = "九星核心：近攻、近防与疲劳；双手斧起步",
        description = "奶团吕布的名号比瑶瑶牙的长柄斧还容易惹人围观。有人盼她逞威风，有人等她摔跟头，递来的请帖里常把挑战写得比报酬更大。她并不讨厌好胜，却不愿每份差事最后都变成必须证明自己最强。破口一击与回看旗子是一前一后的打算：能往前开路，也要知道为什么开、开给谁走。她考虑加入黑旗，想要的既有够硬的任务，也有说话算数的约定。谁先把这两件摆明，谁才值得她听完。",
        attrs = [63, 111, 44, 90, 60, 32, 5, 2],
        stars = { MeleeSkill = 3, MeleeDefense = 3, Stamina = 3 },
        equipment = ["weapons/woodcutters_axe", "armor/padded_surcoat", "helmets/aketon_cap"],
        bag = ["weapons/knife"],
        chapter = 5,
        encounterTitle = "先把委托写在名号上面",
        encounterText = "一名看客拿挑战书来找奶团吕布，瑶瑶牙却先看抹茶摊开的护送安排。她不拒绝比试，只要先弄清自己答应了哪一件事。磨刀匠的斧刃整修费也已列明，黑旗可分担这笔以换取招募优惠；若保留原价邀请，她会自行处理，不必先送上一场胜利来换座位。",
        encounterChoices = [
            { label = "按实际任务谈同行，原价邀约", outcome = "瑶瑶牙把挑战书暂放一边，接受留下原价邀约。黑旗至少肯把具体任务放到名号前面，她愿意再谈。", cost = 0, hireDiscount = 0 },
            { label = "分担斧刃整修费，议低招募价", outcome = "斧刃整修费按约分担，瑶瑶牙相应降低招募报价。她把长柄斧扶正，表示这份诚意值得认真考虑。", cost = 80, hireDiscount = 120 }
        ]
    },
    yangmiemie = {
        name = "羊咩咩",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 340,
        wage = 10,
        background = "daytaler_background",
        role = "生命与决心偏好的稳健配置",
        description = "羊咩咩的轻车轴边挂着小铃，听起来像装饰，实际是她判断车况的一道提醒。直路不必处处争第一，弯后有没有余力、包裹还整不整齐，同样算本事。她也会盯着前车较劲，只是脚下先松半分，手里的方向仍不能乱。掌事若只看抵达次序，她就把碎封蜡摆到计时牌旁。黑旗想请她同行，她希望这支队伍能听完车况再谈速度。快慢都能争，已经答应送到的东西可不能在争论里消失。",
        attrs = [61, 104, 46, 100, 52, 40, 6, 5],
        stars = { Hitpoints = 2, Bravery = 1 },
        equipment = ["weapons/militia_spear", "shields/buckler_shield", "armor/padded_surcoat"],
        bag = [],
        chapter = 5,
        encounterTitle = "计时牌旁的碎封蜡",
        encounterText = "羊咩咩还在请掌事把完好的封蜡算进交付，轴边小铃又响出一点不稳。她打算请车匠校正轮轴，开支已列明。黑旗可以原价留下邀请，也可分担这笔检修费用，换取较低招募报价。至于哪段路能追、哪处弯该松，仍得听她把车况说清。",
        encounterChoices = [
            { label = "认可交付的完整，原价留邀约", outcome = "羊咩咩留下原价招募条件，愿意继续谈同行。她把完好的包裹推到计时牌边，仍打算把刚才那笔工钱争明白。", cost = 0, hireDiscount = 0 },
            { label = "分担轮轴检修费，议低招募价", outcome = "轮轴检修费按约分担，羊咩咩相应降低招募报价。她感谢这份支持，也让团长再记一遍弯前该听什么声音。", cost = 50, hireDiscount = 80 }
        ]
    },
    chenzhihan = {
        name = "陈知含",
        title = "远征团队员",
        isCaptain = false,
        hireCost = 300,
        wage = 9,
        background = "daytaler_background",
        role = "生命、近防与决心均衡的新兵",
        description = "陈知含记得谁还没分到饼，也会把自己那份完整地摆在名字旁。月饼帮可以坐得热闹，坐下的人却不必永远只负责分食。她想学盾，想知道自己怎样挡住下一下，想把上一次看漏的脚步真正记住。谈到这里，她比谈帮忙更有兴致，只是旁人不一定问过。她愿意考虑一支互相照应的队伍，前提是照应里也有她自己。招募纸上除了日薪，还得留出一行她亲口说的愿望。",
        attrs = [57, 100, 45, 105, 50, 37, 6, 4],
        stars = { MeleeDefense = 1, Hitpoints = 1, Bravery = 2 },
        equipment = ["weapons/shortsword", "shields/buckler_shield", "armor/thick_tunic"],
        bag = [],
        chapter = 5,
        encounterTitle = "先把我的名字写上",
        encounterText = "陈知含把自己那份饼放好，主动提出想学盾。她已看中过一副练习用的护腕，摊主把修补与租用的费用列在木牌上。黑旗可以原价留下邀请，认真考虑她想要的岗位；也能分担这笔准备开支换取招募优惠。她终于问的是自己的打算，没有先说大家都行。",
        encounterChoices = [
            { label = "认真考虑她的岗位，原价邀约", outcome = "陈知含接受原价邀约，把想学盾的愿望写进条件。她又确认了一遍自己的那份饼还在，才接着和三位队长聊下去。", cost = 0, hireDiscount = 0 },
            { label = "分担练习护腕费用，议低招募价", outcome = "护腕准备费用按约分担，陈知含相应降低招募报价。她把条件收好，很高兴这次被认真讨论的是自己想做的事。", cost = 40, hireDiscount = 60 }
        ]
    }
};

// Metadata only: keep already recruited actors usable when upgrading older saves.
// Retired identities are never listed or created by new recruitment.
A.RetiredCharacters <- {
    yanzi = { wage = 12, description = "他善于把僵住的场面重新谈下去，也愿意在条件不合适时表明立场。等大家笑过，他会把那句真正难说的话继续讲完。" }
};
