// Reviewed clothing layers only. Native face/hair, equipment and injuries stay
// native; the unaccepted human corpse head and toad neck are never selected.
local A = ::AfeixExpedition;
A.Art <- {
    DiscLayer = "afeix_gameplay_disc",
    DiscBrush = "afeix_g03_feidie",
    BodyPrefix = "afeix_g03_"
};
A.isArtCharacter <- function(bro) {
    return bro != null && this.isOrigin() && bro.getFlags().has("afeix_character")
        && bro.getFlags().get("afeix_character") == "afei";
};
A.isCharacterArtSuspended <- function(bro) {
    return bro != null && "afeixArtSuspendDepth" in bro.m && bro.m.afeixArtSuspendDepth > 0;
};

// Call consistently during player initialization. Untagged players keep this
// layer empty/invisible. Engine sprite serialization is not exposed by the
// inspected scripts; a fixed layer order alone cannot prove old-save safety.
A.ensureCharacterArtLayer <- function(bro) {
    if (bro == null) return null;
    if (!bro.hasSprite(this.Art.DiscLayer)) {
        local sprite = bro.addSprite(this.Art.DiscLayer);
        sprite.Visible = false;
    }
    return bro.getSprite(this.Art.DiscLayer);
};
A.hideCharacterArt <- function(bro) {
    if (bro == null || !bro.hasSprite(this.Art.DiscLayer)) return;
    local disc = bro.getSprite(this.Art.DiscLayer);
    disc.Visible = false;
    disc.resetBrush();
};
A.restoreNativeCharacterBody <- function(bro) {
    if (bro == null || !bro.hasSprite("body")) return false;
    local appearance = bro.getItems().getAppearance();
    if (!("Body" in appearance) || appearance.Body == "" || !bro.doesBrushExist(appearance.Body)) return false;
    local body = bro.getSprite("body");
    body.setBrush(appearance.Body);
    if (bro.hasSprite("head")) {
        body.Color = bro.getSprite("head").Color;
        body.Saturation = bro.getSprite("head").Saturation;
    }
    // A route change can occur while a survivor is still wounded.
    if (bro.hasSprite("injury_body")) {
        local injury = bro.getSprite("injury_body"), brush = appearance.Body + "_injured";
        if (bro.doesBrushExist(brush)) injury.setBrush(brush);
        else injury.resetBrush();
    }
    return true;
};

// Hooks suspend before native serialization and sync on both success and error.
// This removes custom brush references while the script serializer runs; native
// engine save/load behavior and upgrades still need an actual game check.
A.suspendCharacterArt <- function(bro) {
    if (!this.isArtCharacter(bro)) return false;
    this.hideCharacterArt(bro);
    return this.restoreNativeCharacterBody(bro);
};
A.syncCharacterArt <- function(bro) {
    if (!this.isArtCharacter(bro)) return false;
    // Native save/death callbacks may refresh appearance. A per-actor transient
    // counter prevents those nested callbacks from restoring custom brushes.
    if (this.isCharacterArtSuspended(bro)) return false;
    if (!bro.hasSprite("body")) return false;
    if (!bro.m.IsAlive || bro.m.IsDying) {
        this.hideCharacterArt(bro);
        return false;
    }
    local route = "route" in this ? this.route() : "normal";
    local bodyForm = route == "feidie" ? this.get("feidie_base_route", "normal") : route;
    local bodyName = null;
    if (bodyForm == "normal" || bodyForm == "jiahao") bodyName = this.Art.BodyPrefix + bodyForm + "_body";
    local bodyReady = bodyName != null;
    if (bodyReady) foreach (suffix in ["", "_dead", "_injured"]) {
        if (!bro.doesBrushExist(bodyName + suffix)) { bodyReady = false; break; }
    }
    if (bodyReady) {
        local body = bro.getSprite("body");
        body.setBrush(bodyName);
        body.Color = bro.createColor("#ffffff");
        body.Saturation = 1.0;
        // Preserve HideBody and every native armor/helmet visibility decision.
        if (bro.hasSprite("injury_body") && bro.getSprite("injury_body").Visible)
            bro.getSprite("injury_body").setBrush(bodyName + "_injured");
    } else {
        // Includes the toad route: its skills work, its artwork is deferred.
        this.restoreNativeCharacterBody(bro);
    }
    if (route == "feidie" && bro.doesBrushExist(this.Art.DiscBrush)) {
        local disc = this.ensureCharacterArtLayer(bro);
        disc.setBrush(this.Art.DiscBrush);
        disc.Color = bro.createColor("#ffffff");
        disc.Saturation = 1.0;
        disc.setHorizontalFlipping(!bro.isAlliedWithPlayer());
        bro.setSpriteOffset(this.Art.DiscLayer, bro.createVec(0, 0));
        disc.Visible = true;
    } else this.hideCharacterArt(bro);
    bro.setDirty(true);
    return bodyReady || (route == "feidie" && bro.doesBrushExist(this.Art.DiscBrush));
};
