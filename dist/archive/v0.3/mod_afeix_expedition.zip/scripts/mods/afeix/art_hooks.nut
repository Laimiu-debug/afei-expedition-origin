// Separate from gameplay hooks so vanilla lifecycle signatures are explicit.
// Temporary suspension lives in m, never in the serialized character Flags.
::mods_hookExactClass("entity/tactical/player", function(o) {
    local onInit = o.onInit;
    o.onInit = function() {
        this.m.afeixArtSuspendDepth <- 0;
        local result = onInit();
        ::AfeixExpedition.ensureCharacterArtLayer(this);
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onAppearanceChanged = o.onAppearanceChanged;
    o.onAppearanceChanged = function(appearance, setDirty = true) {
        local result = onAppearanceChanged(appearance, setDirty);
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onUpdateInjuryLayer = o.onUpdateInjuryLayer;
    o.onUpdateInjuryLayer = function() {
        local result = onUpdateInjuryLayer();
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onFactionChanged = o.onFactionChanged;
    o.onFactionChanged = function() {
        local result = onFactionChanged();
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onDeserialize = o.onDeserialize;
    o.onDeserialize = function(input) {
        this.m.afeixArtSuspendDepth <- 0;
        ::AfeixExpedition.ensureCharacterArtLayer(this);
        local result = onDeserialize(input);
        // World origin may still be unavailable here. Completed world loading
        // also restores metadata/promotions and invokes syncCharacterArt.
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onCombatFinished = o.onCombatFinished;
    o.onCombatFinished = function() {
        local result = onCombatFinished();
        ::AfeixExpedition.syncCharacterArt(this);
        return result;
    };
    local onDeath = o.onDeath;
    o.onDeath = function(killer, skill, tile, fatalityType) {
        local A = ::AfeixExpedition;
        if (!A.isArtCharacter(this)) return onDeath(killer, skill, tile, fatalityType);
        local depth = "afeixArtSuspendDepth" in this.m ? this.m.afeixArtSuspendDepth : 0;
        this.m.afeixArtSuspendDepth <- depth + 1;
        A.hideCharacterArt(this);
        local result = null;
        try { result = onDeath(killer, skill, tile, fatalityType); }
        catch (error) {
            this.m.afeixArtSuspendDepth = depth;
            A.hideCharacterArt(this);
            throw error;
        }
        this.m.afeixArtSuspendDepth = depth;
        A.hideCharacterArt(this);
        // Native corpse construction uses the selected body + "_dead". Do not
        // restore live art here; unconscious survivors sync after combat.
        return result;
    };
    local onSerialize = o.onSerialize;
    o.onSerialize = function(output) {
        local A = ::AfeixExpedition;
        if (!A.isArtCharacter(this)) return onSerialize(output);
        local depth = "afeixArtSuspendDepth" in this.m ? this.m.afeixArtSuspendDepth : 0;
        this.m.afeixArtSuspendDepth <- depth + 1;
        local result = null;
        try {
            A.suspendCharacterArt(this);
            result = onSerialize(output);
        } catch (error) {
            this.m.afeixArtSuspendDepth = depth;
            if (depth == 0) A.syncCharacterArt(this);
            throw error;
        }
        this.m.afeixArtSuspendDepth = depth;
        if (depth == 0) A.syncCharacterArt(this);
        return result;
    };
});
