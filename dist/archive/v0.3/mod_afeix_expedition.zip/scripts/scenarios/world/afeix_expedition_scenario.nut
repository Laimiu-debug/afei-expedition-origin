this.afeix_expedition_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
    m = {},
    function create()
    {
        this.m.ID = "scenario.afeix_expedition";
        this.m.Name = "阿飞远征团：成长与转职试玩";
        this.m.Description = "[p=c][img]gfx/ui/events/event_80.png[/img][/p][p]阿飞、王大谋、午夜抹抹茶三位队长一起上路。阿飞眼下还很弱，大谋先撑起前排，抹茶在后排帮忙。通过送信与有报酬的契约积累履约记录，逐章结识伙伴。34 位主题成员均可进入队伍。[/p][p]世界地图按 F8 打开黑旗名册。最多 40 人在册、每战最多 10 人；可雇用普通佣兵，换人保留装备与成长。每人拥有一段成长选择，阿飞可转职蛤蟆人或嘉豪；开启六根隐藏支线后还可成为飞碟，后期可付费重修。[/p][p]成长、羁绊与自行车事件从黑旗名册进入。新技能图标、阿飞衣装与头顶飞碟已接入，多数成员仍使用原版外观。数值均为试玩参数，尚待实机验收。阿飞个人阵亡不会单独触发战役结束。[/p]";
        this.m.Difficulty = 2;
        this.m.Order = 87;
        this.m.IsFixedLook = false;
    },
    function isValid() { return "AfeixExpedition" in getroottable(); },
    function onInit()
    {
        this.World.Assets.m.BrothersMax = ::AfeixExpedition.RosterMax;
        this.World.Assets.m.BrothersMaxInCombat = ::AfeixExpedition.CombatMax;
        // Keep the vanilla enemy-scaling parameter; ten-person balance is untested.
        this.World.Assets.m.BrothersScaleMax = 12;
    },
    function onSpawnAssets()
    {
        local A = ::AfeixExpedition;
        A.set("schema", A.Schema);
        this.World.Assets.m.Money = 1800;
        this.World.Assets.m.ArmorParts = 30;
        this.World.Assets.m.Medicine = 15;
        this.World.Assets.m.Ammo = 25;
        if (A.makeCharacter("afei", 3) == null || A.makeCharacter("damou", 4) == null || A.makeCharacter("mocha", 12) == null)
            throw "AfeixExpedition: failed to create the three starting captains";
        local stash = this.World.Assets.getStash();
        foreach (food in this.World.Assets.getFoodItems()) stash.remove(food);
        for (local i = 0; i < 2; i++)
        {
            local food = this.new("scripts/items/supplies/ground_grains_item");
            food.setAmount(25);
            stash.add(food);
        }
        this.World.Assets.updateFood();
        if ("enforceFormation" in A) A.enforceFormation();
    },
    function onSpawnPlayer()
    {
        local settlements = this.World.EntityManager.getSettlements();
        local candidates = [];
        foreach (town in settlements)
            if (!town.isMilitary() && !town.isIsolatedFromRoads() && town.isAlliedWithPlayer()) candidates.push(town);
        // Find a reachable free starting tile with bounded searches, even on an
        // unusual map where the first settlement has no suitable nearby road.
        local village = null;
        local spawnTile = null;
        local nav = this.World.getNavigator().createSettings();
        nav.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;
        foreach (town in candidates)
        {
            local center = town.getTile();
            local shortest = 9000;
            for (local x = this.Math.max(2, center.SquareCoords.X - 4); x <= this.Math.min(this.Const.World.Settings.SizeX - 2, center.SquareCoords.X + 4); x++)
            {
                for (local y = this.Math.max(2, center.SquareCoords.Y - 4); y <= this.Math.min(this.Const.World.Settings.SizeY - 2, center.SquareCoords.Y + 4); y++)
                {
                    if (!this.World.isValidTileSquare(x, y)) continue;
                    local tile = this.World.getTileSquare(x, y);
                    if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore || tile.IsOccupied || tile.getDistanceTo(center) <= 1) continue;
                    local path = this.World.getNavigator().findPath(tile, center, nav, 0);
                    if (!path.isEmpty() && path.getSize() < shortest)
                    {
                        spawnTile = tile;
                        shortest = path.getSize();
                    }
                }
            }
            if (spawnTile != null) { village = town; break; }
        }
        if (spawnTile == null) throw "AfeixExpedition: no reachable free starting tile near a friendly settlement";
        ::AfeixExpedition.set("home_id", village.getID());
        ::AfeixExpedition.set("home_name", village.getNameOnly());
        this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", spawnTile.Coords.X, spawnTile.Coords.Y);
        this.World.Assets.updateLook(1);
        this.World.getCamera().setPos(this.World.State.m.Player.getPos());
        this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function(_tag)
        {
            if (::AfeixExpedition.isOrigin()) ::AfeixExpedition.openLedger();
        }, null);
    },
    function onCombatFinished() { return true; }
});
