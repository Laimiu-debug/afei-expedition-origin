local A = ::AfeixExpedition;

A.ledgerOption <- function(label, action) {
    return { Text = label, Action = action, function getResult(event) { return this.Action(event); } };
};
A.ledgerNav <- function(label, page) {
    return this.ledgerOption(label, function(event) { event.m.Notice = ""; return page; });
};
A.ledgerAction <- function(label, action, page) {
    return this.ledgerOption(label, function(event) {
        local result = action();
        event.m.Notice = result.text;
        return page;
    });
};
A.ledgerStatus <- function(status) {
    local labels = { locked = "尚无线索", encounter = "等待相遇", available = "可以邀请", recruited = "已经入队", dead = "已经阵亡", departed = "已经离队" };
    return status in labels ? labels[status] : "尚无线索";
};
A.ledgerWindow <- function(total, offset) {
    if (offset < 0 || offset >= total) offset = 0;
    local count = ::Math.min(4, total - offset);
    local next = offset + count;
    return { offset = offset, count = count, more = total > 4, next = next >= total ? 0 : next };
};
A.ledgerToggle <- function(event, actorId) {
    local index = event.m.Selected.find(actorId);
    if (index != null) {
        event.m.Selected.remove(index);
        event.m.Notice = "";
    } else if (event.m.Selected.len() >= this.CombatMax) {
        event.m.Notice = "最多选择 " + this.CombatMax + " 人出战。请先取消一位，再加入另一位。";
    } else {
        event.m.Selected.push(actorId);
        event.m.Notice = "";
    }
};
// Factory arguments give every row its own captured actor ID and destination.
A.ledgerActorOption <- function(label, actorId, page) {
    return this.ledgerOption(label, function(event) {
        ::AfeixExpedition.ledgerToggle(event, actorId);
        return page;
    });
};
A.ledgerChapterMembers <- function(chapter) {
    local members = [];
    foreach (key in this.CharacterOrder)
        if (this.Characters[key].chapter == chapter) members.push(key);
    return members;
};
A.ledgerCharacterReturn <- function(key) {
    local chapter = this.Characters[key].chapter;
    local members = this.ledgerChapterMembers(chapter);
    local index = members.find(key);
    return "chapter:" + chapter + ":" + (index == null ? 0 : index / 4 * 4);
};
A.ledgerEncounterOption <- function(label, key, index) {
    return this.ledgerOption(label, function(event) {
        local result = ::AfeixExpedition.resolveEncounter(key, index);
        event.m.Notice = result.text;
        return (result.ok ? "recruit:" : "encounter:") + key;
    });
};

A.ledgerPage <- function(event, page) {
    local A = ::AfeixExpedition;
    local screen = { ID = page, Text = "", Image = "", List = [], Characters = [], Options = [], function start(event) {} };
    local parts = split(page, ":");
    local kind = parts[0];
    local extension = "storyLedgerPage" in A ? A.storyLedgerPage(event, page) : null;
    if (extension == null && "promotionLedgerPage" in A) extension = A.promotionLedgerPage(event, page);
    if (extension != null) {
        screen = extension;
    } else if (kind == "home") {
        screen.Text = "黑旗名册\n\n同行 " + A.roster().len() + " 人；当前出战 " + A.deployedIds().len() + " / 10 人。\n\n任务与伙伴线索都记在这里。原版人物栏仍可调整站位、装备和待命安排。\n世界地图按 F8 可重新打开名册。";
        if (!A.canManage()) screen.Text += "\n\n现在可以查看记录；办理委托、招募和确认编队，请到友好城镇附近或安全扎营处。";
        screen.Options.push(A.ledgerNav("查看任务与交付", "quest"));
        screen.Options.push(A.ledgerNav("查看伙伴与招募", "recruits"));
        screen.Options.push(A.ledgerOption("选择出战成员", function(e) {
            e.m.Selected = clone A.deployedIds();
            e.m.FormationPage = 0;
            e.m.Notice = "";
            return "formation:0";
        }));
        if ("storyLedgerPage" in A) screen.Options.push(A.ledgerNav("成长、转职与伙伴羁绊", "growth"));
        screen.Options.push(A.ledgerOption("合上名册，继续上路", function(e) { return 0; }));
    } else if (kind == "quest") {
        screen.Text = "送信与旅途进度\n\n" + A.questSummary();
        screen.Options.push(A.ledgerAction("领取送信委托", function() { return A.startDelivery(); }, "quest"));
        screen.Options.push(A.ledgerAction("在收信地交付", function() { return A.finishDelivery(); }, "quest"));
        screen.Options.push(A.ledgerNav("放弃这次送信", "quest_cancel"));
        screen.Options.push(A.ledgerNav("返回名册", "home"));
    } else if (kind == "quest_cancel") {
        screen.Text = "放弃这次送信\n\n放弃后不领报酬，已花掉的时间和补给不返还。之后仍可在友好城镇重新领取，也可通过有报酬的普通契约获得伙伴线索。";
        screen.Options.push(A.ledgerAction("确认放弃", function() { return A.cancelDelivery(); }, "quest"));
        screen.Options.push(A.ledgerNav("继续保管信件", "quest"));
    } else if (kind == "recruits") {
        screen.Text = "伙伴与招募\n\n" + A.chapterSummary() + "\n\n可先查看所有伙伴的档案。沿途完成送信和有实际报酬的契约，会逐步带来新的相遇线索；暂缓相遇或邀请不会丢失线索。";
        foreach (chapter in A.Chapters) {
            local label = chapter.name + " · " + (A.isChapterUnlocked(chapter.id) ? "已开启" : "尚未开启");
            screen.Options.push(A.ledgerNav(label, "chapter:" + chapter.id + ":0"));
        }
        screen.Options.push(A.ledgerNav("返回名册", "home"));
    } else if (kind == "chapter" && parts.len() > 1) {
        local id = parts[1].tointeger(), chapter = null;
        foreach (entry in A.Chapters) if (entry.id == id) { chapter = entry; break; }
        if (chapter != null) {
            local members = A.ledgerChapterMembers(id);
            local offset = parts.len() > 2 ? parts[2].tointeger() : 0;
            local window = A.ledgerWindow(members.len(), offset);
            screen.Text = chapter.name + "\n\n旅途进度 " + A.progressCount() + " / " + chapter.required + "。";
            screen.Text += A.isChapterUnlocked(id) ? "本章线索已经开启。" : "达到本章进度后，才能办理新的相遇与招募。";
            screen.Text += "\n\n点开名字可查看档案、相遇条件与邀请费用。";
            for (local i = 0; i < window.count; i++) {
                local key = members[window.offset + i], data = A.Characters[key];
                local label = data.name + " · " + (data.isCaptain ? "开局队长" : A.ledgerStatus(A.characterStatus(key)));
                screen.Options.push(A.ledgerNav(label, "recruit:" + key));
            }
            if (window.more) screen.Options.push(A.ledgerNav(window.next == 0 ? "回到本章第一页" : "本章下一页", "chapter:" + id + ":" + window.next));
        } else screen.Text = "名册里没有这个章节。";
        screen.Options.push(A.ledgerNav("返回章节目录", "recruits"));
    } else if (kind == "recruit" && parts.len() > 1 && parts[1] in A.Characters) {
        local key = parts[1];
        local data = A.Characters[key];
        local state = A.characterStatus(key);
        local price = A.recruitPrice(key);
        screen.Text = data.name + "\n\n" + data.description + "\n\n起步方向：" + data.role + "。\n状态：" + A.ledgerStatus(state) + "。";
        if (data.isCaptain) screen.Text += "\n开局队长；起步日薪 " + data.wage + " 克朗，日后会随成长等因素变化。";
        else screen.Text += "\n当前招募费 " + price + " 克朗；起步日薪 " + data.wage + " 克朗，日后会随成长等因素变化。";
        screen.Text += "\n\n" + A.recruitHint(key);
        if (!data.isCaptain && state == "available") {
            screen.Text += "\n\n请到友好城镇附近正式邀请。资金或名册位置不足时不会扣款，线索仍然保留。";
            screen.Options.push(A.ledgerAction("正式邀请 · " + price + " 克朗", function() { return A.recruit(key); }, page));
        } else if (!data.isCaptain && state == "encounter") {
            screen.Options.push(A.ledgerNav("前往与" + data.name + "相遇", "encounter:" + key));
        } else if (state == "recruited") {
            screen.Text += "\n\n" + data.name + "已在队伍中，可到编队页安排出战或待命。";
        } else if (state == "dead") {
            screen.Text += "\n\n" + data.name + "的名字留在这里，无法再次招募。";
        } else if (state == "departed") {
            screen.Text += "\n\n" + data.name + "已经离开远征团，这份邀请不再有效。";
        }
        screen.Options.push(A.ledgerNav("返回本章伙伴", A.ledgerCharacterReturn(key)));
        screen.Options.push(A.ledgerNav("返回名册", "home"));
    } else if (kind == "encounter" && parts.len() > 1 && parts[1] in A.Characters) {
        local key = parts[1], data = A.Characters[key];
        local state = A.characterStatus(key);
        screen.Text = data.name + "的相遇\n\n" + A.recruitHint(key);
        if (!data.isCaptain && state == "encounter") {
            screen.Text = data.encounterTitle + "\n\n" + data.encounterText + "\n\n请在友好城镇附近作出选择；也可以先返回，线索会继续保留。";
            foreach (index, choice in data.encounterChoices) {
                screen.Text += "\n\n" + (index + 1) + ". " + choice.label + "\n当场支出 " + choice.cost + " 克朗；相遇完成后招募费减免 " + choice.hireDiscount + " 克朗。";
                screen.Options.push(A.ledgerEncounterOption(choice.label + " · " + choice.cost + " 克朗", key, index));
            }
        } else screen.Text += "\n\n当前状态：" + A.ledgerStatus(state) + "。可返回档案查看安排。";
        screen.Options.push(A.ledgerNav("暂缓／返回人物档案", "recruit:" + key));
    } else if (kind == "formation") {
        local brothers = A.roster();
        local offset = parts.len() > 1 ? parts[1].tointeger() : 0;
        local window = A.ledgerWindow(brothers.len(), offset);
        event.m.FormationPage = window.offset;
        local stay = "formation:" + window.offset;
        screen.Text = "选择出战成员\n\n已选 " + event.m.Selected.len() + " / 10 人。点名字可选择或取消；核对并确认前，现有阵容不会改变。\n\n原版人物栏仍能调整站位和装备。";
        if (brothers.len() == 0) screen.Text += "\n\n名册里已经没有同行成员。";
        for (local i = 0; i < window.count; i++) {
            local bro = brothers[window.offset + i];
            local id = bro.getID();
            local selected = event.m.Selected.find(id) != null;
            local label = (selected ? "[已选] " : "[待命] ") + bro.getNameOnly() + " · " + bro.getLevel() + " 级";
            screen.Options.push(A.ledgerActorOption(label, id, stay));
        }
        if (window.more) screen.Options.push(A.ledgerNav(window.next == 0 ? "回到第一页" : "下一页", "formation:" + window.next));
        screen.Options.push(A.ledgerNav("核对名单／返回", "formation_review"));
    } else if (kind == "formation_review") {
        screen.Text = "核对出战名单\n\n已选 " + event.m.Selected.len() + " / 10 人：";
        local found = 0;
        foreach (bro in A.roster()) {
            if (event.m.Selected.find(bro.getID()) == null) continue;
            screen.Text += "\n" + bro.getNameOnly();
            found++;
        }
        if (found == 0) screen.Text += "\n尚未选择成员。";
        screen.Text += "\n\n确认后，未选成员进入待命；原本出战且仍被选中的成员保留站位。取消本次选择不会改变现有阵容。";
        screen.Options.push(A.ledgerOption("确认这份出战名单", function(e) {
            local result = A.applyFormation(clone e.m.Selected);
            e.m.Notice = result.text;
            if (!result.ok) return "formation_review";
            e.m.Selected = [];
            e.m.FormationPage = 0;
            return "home";
        }));
        screen.Options.push(A.ledgerNav("继续选择成员", "formation:" + event.m.FormationPage));
        screen.Options.push(A.ledgerOption("取消本次选择，返回名册", function(e) {
            e.m.Selected = [];
            e.m.FormationPage = 0;
            e.m.Notice = "已取消，出战阵容没有改变。";
            return "home";
        }));
    } else {
        screen.Text = "这一页暂时没有内容，请返回名册。";
        screen.Options.push(A.ledgerNav("返回名册", "home"));
    }
    if (event.m.Notice != "") screen.Text += "\n\n" + event.m.Notice;
    // Six is the native event window's usable button limit; never silently drop an action.
    if (screen.Options.len() > 6) throw "Afeix ledger page exceeds six options: " + page;
    screen.Text = "[img]gfx/ui/events/event_80.png[/img]{" + screen.Text + "}";
    return screen;
};

A.openLedger <- function() {
    if (!this.isOrigin() || ::Tactical.isActive() || ::World.State == null || ::World.Events == null) return false;
    local state = ::World.State;
    if (state.getPlayer() == null || state.getCombatStartTime() != 0 || ::World.Events.hasActiveEvent()) return false;
    if (("State" in ::Tactical) && ::Tactical.State != null) return false;
    if (("LoadingScreen" in getroottable()) && ::LoadingScreen != null
        && (::LoadingScreen.isVisible() || ::LoadingScreen.isAnimating())) return false;
    if (state.m.EventScreen == null || state.m.EventScreen.isVisible() || state.m.EventScreen.isAnimating()) return false;
    local event = ::World.Events.getEvent("event.afeix_ledger");
    if (event == null) return false;
    event.m.AutoPage = "home";
    if (state.m.MenuStack.hasBacksteps()) {
        // Native canFireEvent rejects every menu stack, including towns. Use the
        // town event path only for an already visible town screen at a safe node.
        if (state.m.WorldTownScreen == null || !state.m.WorldTownScreen.isVisible() || !this.canManage()) return false;
        try {
            ::World.Events.m.ActiveEvent = event;
            ::World.Events.m.IsEventShown = true;
            event.fire();
            state.showEventScreenFromTown(event);
            return true;
        } catch (error) {
            event.clear();
            ::World.Events.m.ActiveEvent = null;
            ::World.Events.m.IsEventShown = false;
            ::logError("[AfeixExpedition] Could not open the town ledger: " + error);
            return false;
        }
    }
    if (!::World.Events.canFireEvent(true, true)) return false;
    return ::World.Events.fire("event.afeix_ledger", false);
};
