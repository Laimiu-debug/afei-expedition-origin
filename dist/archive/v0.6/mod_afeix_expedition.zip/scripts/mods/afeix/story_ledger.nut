local A = ::AfeixExpedition;
// Returns raw screens only. The main ledger owns notice text and the image wrapper.
A.storyScreen <- function(page) {
    return { ID = page, Text = "", Image = "", List = [], Characters = [], Options = [], function start(event) {} };
};
A.storyPageNumber <- function(text, fallback = 0) {
    try { return text.tointeger(); } catch (error) { return fallback; }
};
A.storyGrowthLabel <- function(key) {
    local names = { locked = "待历练", ready = "可以成长", done = "已成长", unavailable = "本人不在队" };
    local state = this.growthStatus(key);
    return names[state];
};
A.storyGrowthChoice <- function(key, index) {
    local choice = this.MemberGrowth[key].choices[index];
    return this.ledgerAction(choice.label, function() { return ::AfeixExpedition.resolveGrowth(key, index); }, "member_growth:" + key);
};
A.storyRootChoice <- function(id, index) {
    return this.ledgerAction(this.RootStories[id].choices[index].label,
        function() { return ::AfeixExpedition.resolveRoot(id, index); }, "roots:" + id);
};
A.storyLedgerPage <- function(event, page) {
    local parts = split(page, ":"), kind = parts[0];
    if (kind != "growth" && kind != "member_growth" && kind != "member_growth_chapter"
        && kind != "roots" && kind != "bicycle" && kind != "bicycle_release_confirm") return null;
    local A = ::AfeixExpedition, screen = A.storyScreen(page);
    if (kind == "growth") {
        screen.Text = "成长与彼此的路\n\n每位伙伴达到 3 级、本人实际参战 3 次后，可在安全地点选择一次个人成长。待命不会凭空增加参战次数；两个选项各有温和特长，不锁定武器职业。\n\n阿飞完成自己的成长，是普通晋升的前置之一。六根只要求六段开篇都已触发，回信完成与否另记。";
        screen.Options.push(A.ledgerNav("阿飞晋升与重修", "promotion"));
        screen.Options.push(A.ledgerNav("逐章查看个人成长", "member_growth"));
        screen.Options.push(A.ledgerNav("六根线索与回信", "roots:0"));
        screen.Options.push(A.ledgerNav("蛤妈与旧自行车", "bicycle"));
        screen.Options.push(A.ledgerNav("返回黑旗名册", "home"));
    } else if (kind == "member_growth" && parts.len() == 1) {
        screen.Text = "伙伴的个人成长\n\n按章节查阅所有人的成长场景。已作选择保存在名册里，不会因读档或重新打开此页再发一次。尚未加入的伙伴可以看条件，不能替本人作决定。";
        foreach (chapter in A.Chapters)
            screen.Options.push(A.ledgerNav(chapter.name, "member_growth_chapter:" + chapter.id + ":0"));
        screen.Options.push(A.ledgerNav("返回成长目录", "growth"));
    } else if (kind == "member_growth_chapter") {
        local id = parts.len() > 1 ? A.storyPageNumber(parts[1], -1) : -1;
        local members = [], title = "";
        foreach (chapter in A.Chapters) if (chapter.id == id) title = chapter.name;
        foreach (key in A.CharacterOrder) if (A.Characters[key].chapter == id) members.push(key);
        screen.Text = title == "" ? "没有这一章的成长记录。" : title + " · 个人成长\n\n等级和参战均按本人记录；在队但待命的伙伴仍能处理已经达到条件的成长。";
        local window = A.ledgerWindow(members.len(), parts.len() > 2 ? A.storyPageNumber(parts[2]) : 0);
        for (local i = 0; i < window.count; i++) {
            local key = members[window.offset + i];
            screen.Options.push(A.ledgerNav(A.Characters[key].name + " · " + A.storyGrowthLabel(key), "member_growth:" + key));
        }
        if (window.more) screen.Options.push(A.ledgerNav(window.next == 0 ? "回到本章第一页" : "本章下一页", "member_growth_chapter:" + id + ":" + window.next));
        screen.Options.push(A.ledgerNav("返回成长章节", "member_growth"));
    } else if (kind == "member_growth") {
        local key = parts.len() > 1 ? parts[1] : "";
        if (key in A.MemberGrowth && key in A.Characters) {
            local data = A.MemberGrowth[key], status = A.growthStatus(key);
            screen.Text = A.Characters[key].name + " · " + data.title + "\n\n" + data.scene + "\n\n" + A.growthRequirementText(key);
            foreach (index, choice in data.choices) {
                screen.Text += "\n\n" + (index + 1) + ". " + choice.label + "\n特长：" + choice.traitName + "（" + A.personalBonusText(choice.bonuses) + "）。";
                if (status == "ready") screen.Options.push(A.storyGrowthChoice(key, index));
            }
            if (status == "done") {
                local index = A.get("growth_choice_" + key, -1);
                if (index >= 0 && index < 2) screen.Text += "\n\n已选：" + data.choices[index].label + "\n" + data.choices[index].outcome;
            }
            screen.Options.push(A.ledgerNav("返回本章成长", "member_growth_chapter:" + A.Characters[key].chapter + ":0"));
        } else screen.Text = "没有这位伙伴的个人成长条目。";
        screen.Options.push(A.ledgerNav("返回成长目录", "growth"));
    } else if (kind == "roots" && (parts.len() < 2 || !(parts[1] in A.RootStories))) {
        local window = A.ledgerWindow(A.RootOrder.len(), parts.len() > 1 ? A.storyPageNumber(parts[1]) : 0);
        local count = 0;
        foreach (id in A.RootOrder) if (A.get("root_triggered_" + id, false)) count++;
        screen.Text = "六根 · 开篇 " + count + " / 6\n\n六个人各自的开篇触发即可记账；不要求回信完成、同时在队或同时出战。三位水友代表在履约 3／6／9 份后成为城镇联系人；三位伙伴在曾经入队后留下各自线索，离队或阵亡也不会删掉便笺。\n\n这些联系人不占名册，也不是额外可招募单位。";
        local labels = { locked = "线索未到", ready = "可读开篇", opened = "开篇已记", done = "回信已结" };
        for (local i = 0; i < window.count; i++) {
            local id = A.RootOrder[window.offset + i];
            screen.Options.push(A.ledgerNav(A.RootStories[id].name + " · " + labels[A.rootStatus(id)], "roots:" + id));
        }
        if (window.more) screen.Options.push(A.ledgerNav(window.next == 0 ? "回到第一页" : "下一页", "roots:" + window.next));
        screen.Options.push(A.ledgerNav("返回成长目录", "growth"));
    } else if (kind == "roots") {
        local id = parts[1], data = A.RootStories[id], state = A.rootStatus(id);
        screen.Text = data.name + " · " + data.title;
        if (state == "locked") {
            screen.Text += data.member == "" ? "\n\n累计履约 " + data.required + " 份后，可在友好城镇会面。" : "\n\n" + A.Characters[data.member].name + "曾经入队后，这条开篇线索才会出现。";
        } else if (state == "ready") {
            screen.Text += "\n\n这段独立的开篇已经可以阅读。点下开篇按钮并成功进入对话，便记下这一根；普通招募与仅查看此页不算。";
            screen.Options.push(A.ledgerAction(data.member == "" ? "在城镇听这段开篇" : "阅读留下的开篇便笺",
                function() { return A.triggerRoot(id); }, "roots:" + id));
        } else {
            screen.Text += "\n\n" + data.opening + "\n\n" + data.followup;
            if (state == "opened") {
                screen.Text += "\n\n公共储备须能完整容纳所选奖励；容量不足时不结算、不损失这次领取机会。";
                foreach (index, choice in data.choices) {
                    screen.Text += "\n\n" + choice.label + "：一次支持 " + A.storyRewardText(choice.reward) + "。";
                    screen.Options.push(A.storyRootChoice(id, index));
                }
            } else {
                local index = A.get("root_choice_" + id, -1);
                if (index >= 0 && index < 2) screen.Text += "\n\n已回信：" + data.choices[index].outcome;
                screen.Text += "\n已领取一次支持，不会重复发放。";
            }
        }
        screen.Options.push(A.ledgerNav("返回六根目录", "roots:0"));
        screen.Options.push(A.ledgerNav("返回成长目录", "growth"));
    } else if (kind == "bicycle_release_confirm") {
        local info = A.bicycleInventoryInfo();
        screen.Text = "确认放手\n\n小酒瓶将永久离开本起源名册，不再重新招募。她的成长与身份记录保留，现有 " + info.count + " 件装备将逐件原物放入公共行囊，至少需要相同数量的空位；目前空位 " + info.empty + " 个。满仓或转移失败时取消本次离队，不出售、不丢弃装备。\n\n确认后先读回忆，再决定保留旧车还是推下山坡；两条纪念方向都有不同的温和特长，毁车不是唯一正确答案。";
        screen.Options.push(A.ledgerAction("确认放手并回收全部装备", function() { return A.resolveBicycleDeparture(1, true); }, "bicycle"));
        screen.Options.push(A.ledgerNav("还没决定，返回夜话", "bicycle"));
    } else if (kind == "bicycle") {
        local status = A.bicycleStatus();
        screen.Text = "蛤妈与旧自行车\n\n旧车记在名册的纪念物一栏，不占行囊。小酒瓶曾帮阿飞拨回车链，也有自己的路想走。条件：阿飞 7 级、小酒瓶个人成长完成，两人存活在队，在友好城镇进行夜话。";
        if (status == "ready") {
            screen.Text += "\n\n小酒瓶把手从车把上松开，说起一段想亲自去试的路。阿飞可以把挽留的理由讲明，也可以认真放手；两个人都不欠对方一个必须选的答案。";
            screen.Options.push(A.ledgerAction("说清条件，邀请她继续同行", function() { return A.resolveBicycleDeparture(0); }, "bicycle"));
            screen.Options.push(A.ledgerNav("考虑放手，先查看离队说明", "bicycle_release_confirm"));
        } else if (status == "kept") {
            screen.Text += "\n\n这次夜话选择了继续同行，当时未改变小酒瓶的装备、经验和成长；她后来的去留与生死仍以名册为准。车仍靠在营边，没有发放告别奖励。";
        } else if (status == "memory") {
            screen.Text += "\n\n她已按双方的决定离队，全部 " + A.get("bicycle_returned_items") + " 件装备归库。旧车还在，先回看两人走过的这一段，再决定怎样安放它。";
            screen.Options.push(A.ledgerAction("回看那些没接住又接住的日子", function() { return A.readBicycleMemory(); }, "bicycle"));
        } else if (status == "choice") {
            screen.Text += "\n\n球、车链、盾墙，以及学着自己走的那一句，都已记在这段回忆里。\n留下旧车：阿飞决心 +4、生命 +2。\n推下山坡：阿飞耐力 +5、先攻 +3。\n仅一次纪念特性，不叠加，也不改变后续经验倍率。";
            screen.Options.push(A.ledgerAction("留下旧车，记住共同走过的一程", function() { return A.resolveBicycleMemory(0); }, "bicycle"));
            screen.Options.push(A.ledgerAction("把车推下山坡，亲自走下一段", function() { return A.resolveBicycleMemory(1); }, "bicycle"));
        } else if (status == "done") {
            screen.Text += A.get("bicycle_choice", -1) == 0 ? "\n\n已留下旧车。回忆与这一份特长保留，不再重复结算。" : "\n\n旧车已经推下山坡。下一段路继续，这一份特长不会重复领取。";
        } else if (status == "unavailable") screen.Text += "\n\n阿飞或小酒瓶尚未入队、已离队或阵亡，这次夜话暂不能开始；不会重新生成任何人物。";
        screen.Options.push(A.ledgerNav("返回成长目录", "growth"));
    }
    if (screen.Options.len() > 6) throw "Story page exceeds six buttons: " + page;
    return screen;
};
