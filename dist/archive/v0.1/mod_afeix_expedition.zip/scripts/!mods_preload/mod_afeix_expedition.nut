::AfeixExpedition <- { ID = "mod_afeix_expedition", Version = 1, Schema = 1, CombatMax = 10, RosterMax = 20 };
::AfeixExpedition.setdelegate(getroottable());
foreach (part in ["core", "formation", "quests", "contracts", "roster", "ledger"])
    ::include("scripts/mods/afeix/" + part);

if (!("mods_registerMod" in getroottable()) || !("mods_queue" in getroottable()))
    throw "Afei Expedition requires Legacy Modding Script Hooks (mod_hooks).";
::mods_registerMod("mod_afeix_expedition", 1, "阿飞远征团·起家试玩");
::mods_queue("mod_afeix_expedition", null, function() {
    ::include("scripts/mods/afeix/hooks");
    ::mods_registerJS("afeix/formation.js");
});
