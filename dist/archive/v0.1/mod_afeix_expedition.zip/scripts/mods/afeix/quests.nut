local A = ::AfeixExpedition;
A.isRecruitUnlocked <- function(key) {
    if (key == "afei" || key == "damou" || key == "mocha") return false;
    return (key == "shuaizi" || key == "bottle")
        && (this.get("delivery_state") == 2 || this.get("paid_contracts") > 0);
};
A.findDeliveryTown <- function(home) {
    local best = null, shortest = 999999;
    local settings = ::World.getNavigator().createSettings();
    settings.ActionPointCosts = ::Const.World.TerrainTypeNavCost_Flat;
    foreach (town in ::World.EntityManager.getSettlements()) {
        if (!town.isAlive() || town.getID() == home.getID() || town.isMilitary() || !town.isAlliedWithPlayer()) continue;
        if (!home.isConnectedToByRoads(town)) continue;
        local path = ::World.getNavigator().findPath(home.getTile(), town.getTile(), settings, 0);
        if (!path.isEmpty() && path.getSize() < shortest) { best = town; shortest = path.getSize(); }
    }
    return best;
};
A.startDelivery <- function() {
    if (!this.canManage() || this.currentTown() == null) return this.result(false, "到一座友好城镇附近再领取送信委托。");
    local state = this.get("delivery_state");
    if (state == 2) return this.result(false, "这封信已经交付，报酬也已结清。");
    if (state == 1) return this.result(false, "手中的信尚未交付：目的地是" + this.get("delivery_name", "约定城镇") + "。");
    local destination = this.findDeliveryTown(this.currentTown());
    if (destination == null) return this.result(false, "附近暂时没有可沿道路到达的友好收信城镇。换座城镇再问，或完成一份有报酬的普通契约，同样能获得伙伴线索。");
    this.set("delivery_target", destination.getID());
    this.set("delivery_name", destination.getNameOnly());
    this.set("delivery_x", destination.getTile().SquareCoords.X);
    this.set("delivery_y", destination.getTile().SquareCoords.Y);
    this.set("delivery_state", 1);
    ::World.uncoverFogOfWar(destination.getTile().Pos, 200.0);
    return this.result(true, "信已收好。到" + destination.getNameOnly() + "附近打开黑旗名册交付，报酬 180 克朗。路上的风险与补给仍要自行承担。");
};
A.finishDelivery <- function() {
    if (!this.canManage()) return this.result(false, "现在不适合办理交付。");
    if (this.get("delivery_state") != 1) return this.result(false, "当前没有待交付的信。");
    local destination = ::World.getEntityByID(this.get("delivery_target"));
    if (destination == null || !destination.isAlive() || !destination.isAlliedWithPlayer())
        return this.result(false, "收信地已经无法交付。可在任务页放弃后重新领取，或通过普通有报酬契约获得伙伴线索。");
    local town = this.currentTown();
    if (town == null || town.getID() != destination.getID())
        return this.result(false, "还没到收信地：" + this.get("delivery_name", "约定城镇") + "。");
    this.set("delivery_state", 2);
    ::World.Assets.addMoney(180);
    this.refreshAssets();
    return this.result(true, "收信人点清了账册，付来 180 克朗。白小帅子和小酒瓶听说了这次交付；她们的招募线索已记入黑旗名册，准备好费用后可分别邀请。");
};
A.cancelDelivery <- function() {
    if (!this.canManage()) return this.result(false, "请先到安全地点再处理委托。");
    if (this.get("delivery_state") != 1) return this.result(false, "当前没有可以放弃的送信委托。");
    this.set("delivery_state", 3);
    return this.result(true, "已放弃本次送信，没有报酬。已经消耗的时间和补给不会返还；可在友好城镇重新领取，也可以完成普通契约来建立名声。");
};
// The contract adapter supplies a successful terminal state and observed money received.
// Contract IDs are native persistent IDs; an old completion cannot unlock or count twice.
A.recordContract <- function(id, cancelled, payment) {
    if (!this.isOrigin() || cancelled || payment <= 0 || this.get("contract_done_" + id, false)) return false;
    this.set("contract_done_" + id, true);
    this.set("paid_contracts", this.get("paid_contracts") + 1);
    return true;
};
A.questSummary <- function() {
    local state = this.get("delivery_state"), text;
    if (state == 2) text = "第一封信已经送到，180 克朗报酬已结清。";
    else if (state == 1) text = "目的地：" + this.get("delivery_name", "约定城镇") + "（地图格 " + this.get("delivery_x") + ", " + this.get("delivery_y") + "）。到城镇附近后，在本页选择交付，报酬 180 克朗。";
    else text = (state == 3 ? "上次送信已放弃，可以重新领取。" : "三位队长先把第一封信送到。") + "在友好城镇附近领取委托，沿路抵达另一座城镇。没有强制伏击，路程与正常遭遇仍有风险。";
    text += "\n\n" + (this.isRecruitUnlocked("shuaizi") ? "白小帅子、小酒瓶的线索已开放。暂缓邀请不会丢失线索。" : "完成送信，或成功结算一份有报酬的普通契约，便能得到两位伙伴的线索。");
    return text;
};
