// Prototype values, not final balance. Stable keys never follow roster numbering.
local A = ::AfeixExpedition;
A.CharacterOrder <- ["afei", "damou", "mocha", "shuaizi", "bottle"];
A.Characters <- {
    afei = {
        name = "阿飞", title = "队长", isCaptain = true, hireCost = 0, wage = 8,
        background = "daytaler_background", role = "前期薄弱，保留后续成长空间",
        description = "他爱逞口舌之快，遇上大事却知道轻重。眼下他还不够能打，只能先学着把自己答应的事办妥。三位队长一同上路，带人成为他往后寻找成就感的方向。",
        attrs = [48, 92, 30, 95, 43, 32, 1, 0],
        stars = { MeleeSkill = 2, Bravery = 2, Stamina = 1 },
        equipment = ["weapons/bludgeon", "armor/thick_tunic", "helmets/headscarf", "shields/buckler_shield"],
        bag = []
    },
    damou = {
        name = "王大谋", title = "队长", isCaptain = true, hireCost = 0, wage = 15,
        background = "militia_background", role = "可靠的开局前排",
        description = "远征团起步时，他是三名队长中更能稳住阵线的人。先看清眼前能不能打，再决定往哪走；阿飞尚未站稳的时候，他先把那一段路顶住。",
        attrs = [62, 106, 49, 105, 66, 37, 10, 5],
        stars = { MeleeSkill = 1, MeleeDefense = 1 },
        equipment = ["weapons/boar_spear", "armor/padded_leather", "helmets/aketon_cap", "shields/wooden_shield"],
        bag = []
    },
    mocha = {
        name = "午夜抹抹茶", title = "队长", isCaptain = true, hireCost = 0, wage = 10,
        background = "poacher_background", role = "普通水平的后排帮手",
        description = "三位队长之一。他跟着一起接活、算路和分担补给。开局用弓站在后排，往后怎么配装、怎么培养，仍由玩家决定。",
        attrs = [55, 100, 43, 102, 52, 53, 4, 3],
        stars = { RangedSkill = 1, Bravery = 1 },
        equipment = ["weapons/hunting_bow", "armor/thick_tunic", "helmets/headscarf", "ammo/quiver_of_arrows"],
        bag = ["weapons/knife"]
    },
    shuaizi = {
        name = "白小帅子", title = "远征团队员", isCaptain = false, hireCost = 200, wage = 9,
        background = "militia_background", role = "可培养的持盾前排",
        description = "她先把招募费和日薪问明白，才答应跟着远征团出发。盾牌是她眼下的起点，并不限制以后的武器和培养方向。她通过任务留下线索，正式雇用后成为队伍的一员。",
        attrs = [58, 101, 45, 100, 55, 35, 7, 4],
        stars = { MeleeDefense = 2, Bravery = 1 },
        equipment = ["weapons/shortsword", "armor/padded_surcoat", "shields/wooden_shield"],
        bag = []
    },
    bottle = {
        name = "小酒瓶", title = "蛤妈", isCaptain = false, hireCost = 220, wage = 10,
        background = "daytaler_background", role = "对阿飞成长有帮助的队员",
        description = "小酒瓶是远征团的队员，外号蛤妈。她看得见阿飞爱逞强的样子，也愿意在他还不够可靠的时候帮他一把。这个称呼是队友之间的外号。她完成自己的相遇任务后才加入，并非开局队长。",
        attrs = [56, 100, 44, 101, 57, 38, 5, 3],
        stars = { MeleeSkill = 1, Bravery = 2 },
        equipment = ["weapons/shortsword", "armor/ragged_dark_surcoat", "helmets/hood", "shields/wooden_shield"],
        bag = []
    }
};

A.characterId <- function(_bro)
{
    if (_bro == null || !_bro.getFlags().has("afeix_character")) return "";
    local key = _bro.getFlags().get("afeix_character");
    return typeof key == "string" && key in this.Characters ? key : "";
};

A.findCharacter <- function(_key)
{
    if (!(_key in this.Characters)) return null;
    foreach (bro in this.roster()) if (this.characterId(bro) == _key) return bro;
    return null;
};

A.characterStatus <- function(_key)
{
    if (!(_key in this.Characters)) return "locked";
    if (this.findCharacter(_key) != null) return "recruited";
    if (this.get("dead_" + _key, false)) return "dead";
    if (this.get("departed_" + _key, false) || this.get("ever_" + _key, false)) return "departed";
    return this.isRecruitUnlocked(_key) ? "available" : "locked";
};

// Vanilla serializes the wage multiplier, but recreates base wages and prose
// from the original background. Restore only those definitions after world load.
A.restoreCharacterMetadata <- function(_bro)
{
    if (!this.isOrigin()) return;
    local key = this.characterId(_bro);
    if (key == "") return;
    local data = this.Characters[key], background = _bro.getBackground();
    background.m.DailyCost = data.wage;
    background.m.RawDescription = data.description;
    background.buildDescription(true);
    _bro.getSkills().update();
};

A.makeCharacter <- function(_key, _place = 255)
{
    if (!this.isOrigin() || !(_key in this.Characters)) return null;
    local existing = this.findCharacter(_key);
    if (existing != null) return existing;
    // Losing a named character never creates a new copy of the same person.
    if (this.get("ever_" + _key, false) || this.get("dead_" + _key, false) || this.get("departed_" + _key, false)) return null;
    if (this.roster().len() >= 20) return null;
    local data = this.Characters[_key];
    local roster = ::World.getPlayerRoster();
    local bro = null;
    try
    {
        bro = roster.create("scripts/entity/tactical/player");
        bro.setStartValuesEx([data.background], false);
        bro.getItems().clear();
        bro.setName(data.name);
        bro.setTitle(data.title);
        bro.getFlags().set("afeix_character", _key);
        bro.getFlags().set("afeix_schema", 1);
        bro.getBackground().m.RawDescription = data.description;
        bro.getBackground().buildDescription(true);
        bro.getBackground().m.DailyCost = data.wage;
        bro.getBackground().m.DailyCostMult = 1.0;
        local properties = bro.getBaseProperties();
        local fields = ["Hitpoints", "Stamina", "Bravery", "Initiative", "MeleeSkill", "RangedSkill", "MeleeDefense", "RangedDefense"];
        foreach (index, field in fields) properties[field] = data.attrs[index];
        local talents = bro.getTalents();
        talents.resize(::Const.Attributes.COUNT, 0);
        foreach (index, value in talents) talents[index] = 0;
        foreach (field, stars in data.stars) talents[::Const.Attributes[field]] = stars;
        bro.m.Level = 1;
        bro.m.XP = ::Const.LevelXP[0];
        bro.m.LevelUps = 0;
        bro.m.HireTime = ::Time.getVirtualTimeF();
        bro.fillAttributeLevelUpValues(::Const.XP.MaxLevelWithPerkpoints - 1);
        foreach (path in data.equipment) bro.getItems().equip(::new("scripts/items/" + path));
        foreach (path in data.bag) bro.getItems().addToBag(::new("scripts/items/" + path));
        bro.getSkills().update();
        bro.setHitpoints(bro.getHitpointsMax());
        bro.setPlaceInFormation(_place);
        if ("enforceFormation" in this) this.enforceFormation();
        else ::World.Assets.updateFormation();
    }
    catch (error)
    {
        // An incomplete creation must not consume money or leave a duplicate.
        if (bro != null) roster.remove(bro);
        throw error;
    }
    this.set("ever_" + _key, true);
    return bro;
};

A.recruit <- function(_key)
{
    if (!this.isOrigin() || !(_key in this.Characters)) return this.result(false, "这不是当前起源可招募的人物。");
    if (!this.canManage()) return this.result(false, "请先到安全城镇再办理招募。");
    local town = this.currentTown();
    if (town == null || !town.isAlliedWithPlayer()) return this.result(false, "请先到友好城镇再办理招募。");
    local state = this.characterStatus(_key);
    if (state == "recruited") return this.result(false, "这位队员已经在队伍中，不能重复雇用。");
    if (state == "dead") return this.result(false, "这位队员已经阵亡，不能再次招募。");
    if (state == "departed") return this.result(false, "这位队员已经离队，这个试玩流程不会重新生成她或他。");
    if (state != "available" || this.Characters[_key].isCaptain) return this.result(false, "请先完成对应的相遇任务。");
    if (this.roster().len() >= 20) return this.result(false, "名册已满（20 人）。没有扣款，请先腾出位置。");
    local data = this.Characters[_key];
    if (::World.Assets.getMoney() < data.hireCost) return this.result(false, "需要 " + data.hireCost + " 克朗招募费；当前资金不足，没有扣款。");
    local bro = null;
    try { bro = this.makeCharacter(_key); }
    catch (error)
    {
        ::logError("[AfeixExpedition] Recruit " + _key + " failed: " + error);
        return this.result(false, "人物创建未完成，没有扣款。请查看游戏日志。");
    }
    if (bro == null) return this.result(false, "当前无法创建这位队员，没有扣款。");
    ::World.Assets.addMoney(-data.hireCost);
    if ("enforceFormation" in this) this.enforceFormation();
    this.refreshAssets();
    return this.result(true, data.name + "加入远征团，支付 " + data.hireCost + " 克朗。可在编队页安排上场或待命。");
};
