::AfeixExpedition <- { ID = "mod_afeix_expedition", Version = 2, Schema = 2, CombatMax = 10, RosterMax = 40 };
::AfeixExpedition.setdelegate(getroottable());
foreach (part in ["core", "formation", "characters", "quests", "contracts", "roster", "encounters", "ledger"])
    ::include("scripts/mods/afeix/" + part);

if (!("mods_registerMod" in getroottable()) || !("mods_queue" in getroottable()))
    throw "Afei Expedition requires Legacy Modding Script Hooks (mod_hooks).";
::mods_registerMod("mod_afeix_expedition", 2, "阿飞远征团·全员招募试玩");
::mods_queue("mod_afeix_expedition", null, function() {
    ::include("scripts/mods/afeix/hooks");
    ::mods_registerJS("afeix/formation.js");
});
