local A = ::AfeixExpedition;

A.recruitPrice <- function(key) {
    if (!(key in this.Characters)) return 0;
    local price = this.Characters[key].hireCost - this.get("hire_discount_" + key);
    return price > 0 ? price : 0;
};

A.recruitHint <- function(key) {
    if (!(key in this.Characters)) return "没有这位人物的邀请记录。";
    local data = this.Characters[key];
    if (data.isCaptain) return "这位人物是初始队长，不通过邀请重新生成。";
    local status = this.characterStatus(key);
    if (status == "recruited") return "已经入队；可在编队页安排出战或待命。";
    if (status == "dead") return "已经阵亡，邀请无法重新领取。";
    if (status == "departed") return "已经永久离队，不再生成同一位伙伴。";
    if (!this.isChapterUnlocked(data.chapter)) {
        foreach (chapter in this.Chapters) if (chapter.id == data.chapter)
            return chapter.name + "需要累计完成 " + chapter.required + " 份送信或有实际报酬的契约；当前 " + this.progressCount() + " 份。";
    }
    if (!this.isRecruitUnlocked(key)) return "已找到相遇线索。到友好城镇附近，先在人物页完成“" + data.encounterTitle + "”。可暂缓，不会丢失线索。";
    return "邀请已保留。到友好城镇附近办理；当前招募费 " + this.recruitPrice(key) + " 克朗。";
};

A.resolveEncounter <- function(key, choiceIndex) {
    if (!this.isOrigin() || !(key in this.Characters) || this.Characters[key].isCaptain)
        return this.result(false, "没有可办理的相遇。");
    if (!this.canManage() || this.currentTown() == null)
        return this.result(false, "请到安全的友好城镇附近完成相遇。");
    if (this.characterStatus(key) != "encounter")
        return this.result(false, "这次相遇尚未开放，或已经处理过；没有重复扣款。");
    local data = this.Characters[key];
    if (typeof choiceIndex != "integer" || choiceIndex < 0 || choiceIndex >= data.encounterChoices.len())
        return this.result(false, "请选择有效的处理方式。");
    local choice = data.encounterChoices[choiceIndex];
    if (::World.Assets.getMoney() < choice.cost)
        return this.result(false, "这项选择需要 " + choice.cost + " 克朗，资金不足，没有扣款。可以稍后回来，或选择另一种处理方式。");
    // The result is durable and one-shot; hiring remains a separate transaction.
    if (choice.cost > 0) ::World.Assets.addMoney(-choice.cost);
    this.set("encounter_choice_" + key, choiceIndex);
    this.set("hire_discount_" + key, choice.hireDiscount);
    this.set("encounter_done_" + key, true);
    this.refreshAssets();
    return this.result(true, choice.outcome + "\n\n" + data.name + "的邀请已保留。本次支付 " + choice.cost + " 克朗；正式招募费为 " + this.recruitPrice(key) + " 克朗。未正式邀请前不会占用名册或领取工资。");
};
