// Procedural water over the frozen tactical scene. The backend owns elapsed
// time and deaths; no frontend timer can continue into the next battle.
(function () {
    "use strict";
    var proto = TacticalScreen.prototype;
    function clamp(v) { return Math.max(0, Math.min(1, v)); }
    function ease(v) { v = clamp(v); return v * v * (3 - 2 * v); }
    function front(x, w, h, flood, time) {
        return h * (1.06 - 1.16 * ease(flood))
            + h * (0.012 * Math.sin(x / w * 19 + time * 1.7)
            + 0.006 * Math.sin(x / w * 43 - time * 1.1));
    }
    function bottomPath(ctx, w, h, flood, time, offset) {
        ctx.beginPath();
        ctx.moveTo(-8, h + 8);
        for (var x = -8; x <= w + 16; x += 12) ctx.lineTo(x, front(x, w, h, flood, time) + offset);
        ctx.lineTo(w + 16, h + 8); ctx.closePath();
    }
    function paintWater(ctx, w, h, flood, time) {
        ctx.save();
        bottomPath(ctx, w, h, flood, time, 0); ctx.clip();
        var color = ctx.createLinearGradient(0, front(0, w, h, flood, time), 0, h);
        color.addColorStop(0, "rgba(29,49,48,0.53)");
        color.addColorStop(0.25, "rgba(14,29,31,0.66)");
        color.addColorStop(1, "rgba(5,13,17,0.81)");
        ctx.fillStyle = color; ctx.fillRect(0, 0, w, h);
        // Broken, uneven wavelets rather than a smooth modern gradient wipe.
        for (var row = 0; row < 23; row++) {
            var baseY = h * row / 22 + Math.sin(time * 0.8 + row) * h * 0.006;
            for (var col = 0; col < 11; col++) {
                var left = (col * 113 + row * 71) % 1170 / 1170 * w;
                var length = w * (0.022 + ((row * 7 + col * 3) % 6) * 0.008);
                ctx.beginPath();
                for (var p = 0; p <= 5; p++) {
                    var px = left + length * p / 5;
                    var py = baseY + Math.sin(p * 0.8 + row * 1.7 + col + time * 1.5) * h * 0.003;
                    if (p === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
                }
                ctx.lineWidth = row % 4 === 0 ? 1.7 : 0.8;
                ctx.strokeStyle = row % 4 === 0 ? "rgba(135,155,132,0.16)" : "rgba(83,116,114,0.20)";
                ctx.stroke();
            }
        }
        ctx.restore();
        // Two irregular foam crests follow the advancing shoreline.
        for (var band = 0; band < 2; band++) {
            ctx.beginPath();
            for (var x = 0; x <= w + 12; x += 12) {
                var y = front(x, w, h, flood, time) + band * 5;
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.lineWidth = band === 0 ? 2.0 : 0.9;
            ctx.strokeStyle = band === 0 ? "rgba(6,16,19,0.75)" : "rgba(163,174,143,0.30)";
            ctx.stroke();
        }
    }
    function paintSides(ctx, w, h, flood, time) {
        var reach = w * 0.115 * ease(flood);
        for (var side = 0; side < 2; side++) {
            ctx.save();
            if (side === 1) { ctx.translate(w, 0); ctx.scale(-1, 1); }
            ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(0, -8);
            for (var y = -8; y <= h + 12; y += 12) {
                var x = reach * (0.5 + y / h * 0.75)
                    + reach * 0.13 * Math.sin(y / h * 17 + time);
                ctx.lineTo(x, y);
            }
            ctx.closePath(); ctx.fillStyle = "rgba(5,15,18,0.49)"; ctx.fill();
            ctx.restore();
        }
    }
    function paint(self, elapsed) {
        var tide = self._afeixDreamTide;
        if (!tide) return;
        var vw = Math.max(1, window.innerWidth), vh = Math.max(1, window.innerHeight);
        var width = Math.min(1280, vw), height = Math.round(width * vh / vw);
        if (tide.canvas.width !== width || tide.canvas.height !== height) {
            tide.canvas.width = width; tide.canvas.height = height;
        }
        var ctx = tide.ctx;
        ctx.clearRect(0, 0, width, height);
        var flood = clamp(elapsed / tide.floodSeconds);
        paintWater(ctx, width, height, flood, elapsed);
        paintSides(ctx, width, height, flood, elapsed);
        var black = ease((elapsed - tide.fadeAt) / (tide.duration - tide.fadeAt));
        if (black > 0) { ctx.fillStyle = "rgba(0,0,0," + black + ")"; ctx.fillRect(0, 0, width, height); }
    }
    proto.afeixStopDreamTide = function (data) {
        var token = data && data.Token;
        if (typeof token === "number") this._afeixDreamTideFence = Math.max(this._afeixDreamTideFence || 0, token);
        var tide = this._afeixDreamTide;
        // A delayed stop from an older battle must not clear a newer tableau.
        if (!tide || (typeof token === "number" && token < tide.token)) return;
        this._afeixDreamTideFence = Math.max(this._afeixDreamTideFence || 0, tide.token);
        if (tide.canvas.parentNode) tide.canvas.parentNode.removeChild(tide.canvas);
        this._afeixDreamTide = null;
    };
    proto.afeixStartDreamTide = function (data) {
        if (!data || typeof data.Token !== "number" || data.Token <= (this._afeixDreamTideFence || 0)) return;
        if (this._afeixDreamTide && data.Token <= this._afeixDreamTide.token) return;
        this.afeixStopDreamTide(null);
        // Native disconnect may beat an already queued start message.
        if (this.mSQHandle === null) { this._afeixDreamTideFence = data.Token; return; }
        var canvas = document.createElement("canvas"), ctx = canvas.getContext("2d");
        if (!ctx) { this._afeixDreamTideFence = data.Token; return; }
        canvas.id = "afeix-dream-black-tide";
        canvas.style.position = "fixed"; canvas.style.left = "0"; canvas.style.top = "0";
        canvas.style.width = "100%"; canvas.style.height = "100%";
        canvas.style.zIndex = "5"; canvas.style.pointerEvents = "none";
        // Keep it outside the hidden tactical controls container.
        document.body.appendChild(canvas);
        this._afeixDreamTide = { token: data.Token, canvas: canvas, ctx: ctx, elapsed: -1,
            floodSeconds: data.FloodSeconds, fadeAt: data.FadeAt, duration: data.Duration };
        paint(this, 0);
    };
    proto.afeixDreamTideFrame = function (data) {
        var tide = this._afeixDreamTide;
        if (!tide || !data || data.Token !== tide.token || typeof data.Elapsed !== "number"
            || !isFinite(data.Elapsed) || data.Elapsed < tide.elapsed) return;
        tide.elapsed = Math.max(0, data.Elapsed);
        paint(this, tide.elapsed);
    };
    var disconnect = proto.onDisconnection;
    proto.onDisconnection = function () {
        this.afeixStopDreamTide(null);
        return disconnect.apply(this, arguments);
    };
    var destroy = proto.destroyDIV;
    proto.destroyDIV = function () {
        this.afeixStopDreamTide(null);
        return destroy.apply(this, arguments);
    };
}());
