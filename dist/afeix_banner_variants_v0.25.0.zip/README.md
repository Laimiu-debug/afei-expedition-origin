# 蛤蟆旗帜备选素材 v0.25.0

包含正面踩球、侧身踩球、圆章蛤蟆和黄金天使蛙四款透明 PNG。

解压后打开 `variants/index.html` 对比，`variants/README.md` 保存完整提示词。

图像使用内置 imagegen 生成；`sources/` 和 `variants/references/` 为风格与角色参考。

这是美术素材包，不是可安装的 Mod，请勿放入游戏 data 目录。
