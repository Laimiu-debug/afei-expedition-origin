local A = ::AfeixExpedition;
A.dreamPage <- function(event, id) {
    local A = this;
    local screen = { ID = id, Title = "三人同梦", Text = "", Image = "", Banner = "", Characters = [], List = [], Options = [], function start(e) {} };
    if (id == "opening") {
        screen.Text = this.get("dream_notice", "") + "阿飞、抹茶与大谋围着营火摊开地图，商量明天往哪一座城走。夜深后，三人先后睡去，却走进了同一个地方。\n\n黑旗之下，刀一十人已经齐聚。全员11级，传奇兵器、护甲各循自己的职责；默契的站位像是许多场战斗留下的习惯。\n\n梦境由四幕短战组成，每一幕都会从完整阵容和完好装备重新展开。最后面对斗鱼，第三轮结束后，三人便会从败北的梦潮里醒来。\n\n梦醒后，三人仍会带着原来的行囊上路，在大陆上结识伙伴，选择自己的队伍。";
        screen.Options.push(this.ledgerOption("走进这场梦。", function(e) { ::AfeixExpedition.set("dream_notice", ""); ::AfeixExpedition.queueDreamCombat(); return 0; }));
        screen.Options.push(this.ledgerOption("跳过梦境，三人直接启程。", function(e) { ::AfeixExpedition.skipDream(); return 0; }));
    } else if (id == "stage") {
        local d = this.DreamStages[this.dreamStage()];
        screen.Title = d.name;
        screen.Text = this.get("dream_notice", "") + d.text;
        if (this.dreamStage() == 3) {
            screen.Image = "ui/events/afeix_douyu.png";
            screen.Text = "[p=c][img]gfx/" + screen.Image + "[/img][/p]" + screen.Text;
        }
        screen.Options.push(this.ledgerOption("继续走向前方。", function(e) { ::AfeixExpedition.set("dream_notice", ""); ::AfeixExpedition.queueDreamCombat(); return 0; }));
        screen.Options.push(this.ledgerOption("让梦停在这里，三人启程。", function(e) { ::AfeixExpedition.skipDream(); return 0; }));
    } else if (id == "wake") {
        screen.Title = "黑旗初醒";
        screen.Text = this.get("dream_wake_reason", "") == "douyu"
            ? "斗鱼的背鳍掀起最后一道梦潮。传奇护甲没有碎，黑旗却连同脚下的空地一起散开。十人的声音被水声吞没，三位队长同时睁开眼。\n\n营火只剩余烬。大谋先问：‘你们也看见了？’抹茶伸手摸向账本，阿飞望着尚未写满的黑旗，过了片刻才点头。\n\n地图仍在，路也仍在。这回他们得亲自找到愿意同行的人，慢慢长成自己的模样，再去面对斗鱼。"
            : "梦中的队伍散进了晨雾。阿飞、抹茶与大谋先后醒来，发现彼此记得同样的黑旗、同样的伙伴，还有雾里的斗鱼。\n\n营火已经熄了，原来的装备与行囊仍在手边。梦只是一个开始；三人整理地图，准备在大陆上寻找愿意同行的人。";
        screen.Options.push(this.ledgerOption("收好地图，黑旗启程。", function(e) { ::AfeixExpedition.set("dream_wake_pending", false); return 0; }));
    } else if (id == "dream_final") {
        screen.Title = "再赴梦潮";
        if (this.get("douyu_final_defeated", false)) screen.Text = "斗鱼已经倒下。梦中的十人曾经走到这里，如今赢下这一战的是你亲自组建的黑旗。";
        else if (!this.get("douyu_final_unlocked", false)) {
            screen.Text = "三位队长曾围着营火做过同一个梦。黑旗之下，刀一十人已经成长，雾中的斗鱼却仍挡着前路。\n\n可以回看这段梦境，再由现在的队伍走向终局。";
            if (this.dreamStatus() == "unseen" && this.canManage()) screen.Options.push(this.ledgerOption("回看三人的梦境序章。", function(e) { ::AfeixExpedition.initializeDreamOpening(); return 0; }));
            else if (this.dreamStatus() == "pending" && this.canManage()) screen.Options.push(this.ledgerOption("继续梦境序章。", function(e) { ::AfeixExpedition.DreamOpeningQueued = true; return 0; }));
            if (!this.canManage()) screen.Text += "\n\n请先到友好城镇旁，或在允许扎营的地点停下扎营，确保附近没有敌军，再回看梦境。";
            screen.Text += "\n\n" + this.douyuWorldIntel();
            screen.Options.push(this.ledgerOption("把祭场方位记在地图上。", function(e) { ::AfeixExpedition.queueDouyuMapFocus(); return 0; }));
        }
        else {
            screen.Image = "ui/events/afeix_douyu.png";
            screen.Text = this.douyuWorldIntel() + "\n\n斗鱼在梦潮祭场等待黑旗。它会预告扑击、掀起弹幕浪潮，并点燃火箭礼炮；观察出招，留好撤路，再抓住失衡后的空隙。\n\n整理现实名册，带上自由选择的队员从大陆前往祭场，最多十二人出战。建议以11级、完备配装挑战；伤亡与消耗照常记入旅程，撤退或败战后可以再来。真正击杀斗鱼，将掉落三件传奇装备。";
            screen.Text = "[p=c][img]gfx/" + screen.Image + "[/img][/p]" + screen.Text;
            screen.Options.push(this.ledgerOption("把祭场方位记在地图上。", function(e) { ::AfeixExpedition.queueDouyuMapFocus(); return 0; }));
        }
        screen.Options.push(this.ledgerOption("返回黑旗名册。", function(e) { return "home"; }));
    } else if (id == "victory") {
        screen.Title = "梦潮已破";
        screen.Image = "ui/events/afeix_douyu.png";
        screen.Text = "斗鱼终于倒在黑旗之前。三人曾在同一个梦里看见过传奇队伍，也看见过队伍败下阵来。\n\n如今站在这里的人，是一路相遇、作出选择、互相接应后走来的伙伴。黑旗收起，回去的路已经在脚下。";
        screen.Text = "[p=c][img]gfx/" + screen.Image + "[/img][/p]" + screen.Text;
        screen.Options.push(this.ledgerOption("带大家回家。", function(e) { ::AfeixExpedition.set("douyu_final_notice", false); return 0; }));
    } else return null;
    return screen;
};
